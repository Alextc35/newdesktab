/** Shared SVG factories for feature-owned views. */
const SVG_NS = 'http://www.w3.org/2000/svg';
const ICON_KINDS = new Set(['bookmark', 'folder', 'recycle-bin']);
let folderImagePatternId = 0;

/** Creates the chevron used by expandable controls. */
export function createChevronSvg() {
  const svg = createSvg('0 0 24 24', 'disclosure-chevron');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '2');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.append(createPath('m6 9 6 6 6-6', 'disclosure-chevron-path'));
  return svg;
}

/** Compact tool used to mark a feature that is still being developed. */
export function createDevelopmentSvg() {
  const svg = createSvg('0 0 24 24', 'development-tool-svg');
  svg.setAttribute('fill', 'none');
  svg.setAttribute('stroke', 'currentColor');
  svg.setAttribute('stroke-width', '1.7');
  svg.setAttribute('stroke-linecap', 'round');
  svg.setAttribute('stroke-linejoin', 'round');
  svg.append(createPath('m14.5 6.5 3 3L21 6a6 6 0 0 1-7.6 7.6l-6.8 6.8a2.1 2.1 0 0 1-3-3l6.8-6.8A6 6 0 0 1 18 3Z',
    'development-tool-path'));
  return svg;
}

/** Creates the compact undo or redo arrow for draft editor controls. */
export function createHistorySvg(direction) {
  const svg = createSvg('0 0 24 24', 'editor-history-icon');
  const path = createPath('M9 5 4 10l5 5M4 10h10a6 6 0 0 1 0 12', 'editor-history-arrow');
  if (direction === 'redo') path.setAttribute('transform', 'translate(24 0) scale(-1 1)');
  svg.append(path);
  return svg;
}

/** Creates the fixed-ratio folder artwork shared by every dynamic folder surface. */
export function createFolderSvg(backgroundImageUrl = null) {
  const svg = createSvg('0 0 136 100', 'folder-svg');
  svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
  // Join the open tab contour to the body's top edge without a second seam.
  const tab = createPath(
    'M12 24V14a8 8 0 0 1 8-8h32a10 10 0 0 1 8 4l10.5 14',
    'folder-tab'
  );
  const body = createPath(
    'M7 24h122a7 7 0 0 1 7 7v59a10 10 0 0 1-10 10H10A10 10 0 0 1 0 90V31a7 7 0 0 1 7-7Z',
    'folder-svg-body'
  );

  if (backgroundImageUrl) {
    const patternId = `folder-image-pattern-${++folderImagePatternId}`;
    const defs = document.createElementNS(SVG_NS, 'defs');
    const pattern = document.createElementNS(SVG_NS, 'pattern');
    pattern.id = patternId;
    pattern.setAttribute('patternUnits', 'userSpaceOnUse');
    pattern.setAttribute('width', '136');
    pattern.setAttribute('height', '100');

    const fallback = document.createElementNS(SVG_NS, 'rect');
    fallback.classList.add('folder-svg-image-fallback');
    fallback.setAttribute('width', '136');
    fallback.setAttribute('height', '100');
    const image = document.createElementNS(SVG_NS, 'image');
    image.classList.add('folder-svg-image');
    image.setAttribute('width', '136');
    image.setAttribute('height', '100');
    image.setAttribute('preserveAspectRatio', 'xMidYMid slice');
    image.setAttribute('href', backgroundImageUrl);
    pattern.append(fallback, image);
    defs.append(pattern);
    svg.append(defs);
    tab.style.fill = `url(#${patternId})`;
    body.style.fill = `url(#${patternId})`;
  }

  svg.append(tab, body, createPath('M13 27h110', 'folder-svg-highlight'));
  return svg;
}

/** One bin silhouette: closed on cards, open in its contents and on interaction. */
export function createRecycleBinSvg({ open = false } = {}) {
  const svg = createSvg('0 0 92 108', 'recycle-bin-svg');
  svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
  svg.classList.toggle('is-open', open);
  const lid = document.createElementNS(SVG_NS, 'g');
  lid.classList.add('recycle-bin-lid-group');
  lid.append(
    createPath('M34 14V9.5A5.5 5.5 0 0 1 39.5 4h13A5.5 5.5 0 0 1 58 9.5V14',
      'recycle-bin-handle'),
    createPath('M13 18h66', 'recycle-bin-lid')
  );
  svg.append(
    lid,
    createPath('M20 31h52l-5.4 64.7a9 9 0 0 1-9 8.3H34.4a9 9 0 0 1-9-8.3L20 31Z',
      'recycle-bin-can'),
    createPath('M35 46v39M57 46v39', 'recycle-bin-slots')
  );
  return svg;
}

/** Creates the compact edit indicator used on editable modal glyphs. */
export function createEditIndicatorSvg() {
  const svg = createSvg('0 0 24 24', 'edit-indicator-svg');
  svg.setAttribute('preserveAspectRatio', 'xMidYMid meet');
  svg.append(
    createPath('M5 19h3.5L19 8.5 15.5 5 5 15.5V19Z', 'edit-indicator-pencil'),
    createPath('m13.8 6.7 3.5 3.5', 'edit-indicator-detail')
  );
  return svg;
}

/** Creates a pair of real SVG assets and lets CSS select the active interface theme. */
export function createThemedAssetIcon(kind) {
  if (!ICON_KINDS.has(kind)) throw new TypeError(`Unknown NewDeskTab icon: ${kind}`);

  const wrapper = document.createElement('span');
  wrapper.className = `newdesktab-themed-icon newdesktab-${kind}-icon`;
  wrapper.setAttribute('aria-hidden', 'true');
  for (const theme of ['light', 'dark']) {
    const image = document.createElement('img');
    image.className = `newdesktab-themed-icon-${theme}`;
    image.src = new URL(`../../assets/icons/${kind}-${theme}.svg`, import.meta.url).href;
    image.alt = '';
    image.draggable = false;
    wrapper.append(image);
  }
  return wrapper;
}

function createSvg(viewBox, className) {
  const svg = document.createElementNS(SVG_NS, 'svg');
  svg.setAttribute('viewBox', viewBox);
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('focusable', 'false');
  svg.classList.add(className);
  return svg;
}

function createPath(d, className) {
  const path = document.createElementNS(SVG_NS, 'path');
  path.setAttribute('d', d);
  path.classList.add(className);
  return path;
}
