import { changeLanguage, subscribeLanguageChange, t } from '../../platform/i18n/i18n.js';
import { LANGUAGE_CATALOG, getLanguageSearchTerms } from '../../domain/settings/languageCatalog.js';
import { refreshCustomSelect } from '../../shared/ui/customSelect.js';
import { getInitialSnapshot } from './settingsDraft.js';
import {
  getDraftLanguage,
  setDraftLanguage
} from './settingsDraft.js';

/**
 * Initializes the language section inside the settings modal.
 *
 * This section is responsible for:
 * - syncing the language select with the draft settings state
 * - applying language changes immediately for live preview
 * - restoring the initial language when changes are cancelled
 *
 * @param {Object} params
 * @param {Function} params.onRequestSaveStateUpdate - Callback used to refresh save-state indicators.
 * @returns {{ syncUI: Function, restoreInitialLanguage: Function }}
 */
export function initLanguageSection({
  onRequestSaveStateUpdate
}) {
  /* ==================================================
     DOM
  ================================================== */

  /**
   * Language selector used to switch the current UI language.
   */
  const languageSelect = document.getElementById('language-select');
  const browserOption = languageSelect.querySelector('[value="system"]');
  const orderedLanguages = [...LANGUAGE_CATALOG].sort((a, b) => a.name.localeCompare(b.name, 'en'));
  languageSelect.replaceChildren(browserOption, ...orderedLanguages.map(language => {
    const option = new Option(language.name, language.code);
    option.lang = language.code.replaceAll('_', '-');
    option.dir = language.direction ?? 'ltr';
    return option;
  }));

  function localizeSearch() {
    const uiLanguage = document.documentElement.lang || 'en';
    languageSelect.dataset.searchPlaceholder = t('settingsModal.languages.search');
    languageSelect.dataset.searchEmpty = t('settingsModal.languages.empty');
    for (const language of LANGUAGE_CATALOG) {
      languageSelect.querySelector(`[value="${language.code}"]`).dataset.searchTerms =
        getLanguageSearchTerms(language, uiLanguage);
    }
    refreshCustomSelect(languageSelect);
  }
  localizeSearch();
  subscribeLanguageChange(localizeSearch);

  /* ==================================================
     Sync
  ================================================== */

  /**
   * Synchronizes the language select with the current draft language.
   */
  function syncUI() {
    languageSelect.value = getDraftLanguage();
    refreshCustomSelect(languageSelect);
  }

  /**
   * Restores the language that was active when the settings modal was opened.
   *
   * This is used when the user cancels changes after previewing
   * a different language inside the modal.
   */
  async function restoreInitialLanguage() {
    const initialLanguage = getInitialSnapshot().language;
    await changeLanguage({ language: initialLanguage });
  }

  /* ==================================================
     Events
  ================================================== */

  /**
   * Updates the draft language when the selection changes,
   * applies the new language immediately, and refreshes save-state indicators.
   */
  languageSelect.addEventListener('change', async () => {
    const value = languageSelect.value;

    setDraftLanguage(value);
    syncUI();

    await changeLanguage({ language: value });

    onRequestSaveStateUpdate();
  });

  /* ==================================================
     API
  ================================================== */

  /**
   * Public API for the language settings section.
   */
  return {
    syncUI,
    restoreInitialLanguage
  };
}
