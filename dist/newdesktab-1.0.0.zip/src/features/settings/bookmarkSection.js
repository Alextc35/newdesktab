import { flashSuccess } from '../../shared/ui/flash.js';
import { openBookmarkPresetEditor } from '../bookmarks/bookmarkModal.js';
import { t } from '../../platform/i18n/i18n.js';
import { deleteAllBookmarks } from '../bookmarks/bookmarkDestructiveActions.js';
import { initImportExportButtons } from '../bookmarks/bookmarkImportExport.js';
import { getState } from '../../state/appStore.js';
import {
  commitDraftBookmarkDefault,
  getDraftBookmarkDefault,
  getDraftBookmarkDragMode,
  getDraftBookmarkPresets,
  getDraftBookmarkResizeMode,
  replaceDraftBookmarkPresets,
  setDraftBookmarkDragMode,
  setDraftBookmarkResizeMode
} from './settingsDraft.js';
import { updateSettings } from './settingsActions.js';
import { createBehaviorPreview } from './behaviorPreview.js';

/**
 * Initializes the bookmark settings section.
 *
 * @param {Object} params
 * @param {Function} params.onRequestSaveStateUpdate - Callback used to refresh save-state indicators.
 * @returns {{ syncUI: Function }}
 */
export function initBookmarkSection({ onRequestSaveStateUpdate }) {
  const bookmarkConfigureBtn = document.getElementById('settings-bookmark-configure');
  const exportBtn = document.getElementById('export-btn');
  const importBtn = document.getElementById('import-btn');
  const importInput = document.getElementById('import-input');
  const deleteAllBtn = document.getElementById('delete-all-btn');
  const dragModeInputs = Array.from(document.querySelectorAll(
    'input[name="bookmark-drag-mode"]'
  ));
  const resizeModeInputs = Array.from(document.querySelectorAll(
    'input[name="bookmark-resize-mode"]'
  ));
  const behaviorSections = Array.from(document.querySelectorAll(
    '.bookmark-behavior-settings'
  ));
  const dragModeSummary = document.getElementById('bookmark-drag-settings-summary');
  const resizeModeSummary = document.getElementById('bookmark-resize-settings-summary');
  const dragPreview = document.getElementById('bookmark-drag-preview');
  const resizePreview = document.getElementById('bookmark-resize-preview');
  const dragAnimation = dragPreview ? createBehaviorPreview(dragPreview, 'drag') : null;
  const resizeAnimation = resizePreview ? createBehaviorPreview(resizePreview, 'resize') : null;

  for (const section of behaviorSections) initCollapsibleSection(section);
  collapseBehaviorSections();

  initImportExportButtons(exportBtn, importInput);

  bookmarkConfigureBtn.addEventListener('click', () => {
    openBookmarkPresetEditor(getDraftBookmarkDefault(), {
      onApply: async preset => {
        await updateSettings({ bookmarkDefault: preset });
        if (getState().ui.persistence.status === 'error') {
          throw new Error('Could not persist the default bookmark style.');
        }

        commitDraftBookmarkDefault(preset);
        onRequestSaveStateUpdate();
        flashSuccess('flash.settings.bookmarkDefaultSaved');
      },
      getPresets: getDraftBookmarkPresets,
      replacePresets: replaceDraftBookmarkPresets,
      onPresetsChange: onRequestSaveStateUpdate
    });
  });

  for (const input of dragModeInputs) {
    input.addEventListener('change', () => {
      if (!input.checked) return;
      setDraftBookmarkDragMode(input.value);
      renderDragMode();
      onRequestSaveStateUpdate();
    });
  }

  for (const input of resizeModeInputs) {
    input.addEventListener('change', () => {
      if (!input.checked) return;
      setDraftBookmarkResizeMode(input.value);
      renderResizeMode();
      onRequestSaveStateUpdate();
    });
  }

  function renderDragMode() {
    const mode = getDraftBookmarkDragMode();
    for (const input of dragModeInputs) {
      input.checked = input.value === mode;
      input.closest('.drag-mode-option')?.classList.toggle(
        'is-selected',
        input.checked
      );
    }
    if (dragModeSummary) {
      dragModeSummary.textContent = t(`settingsModal.bookmark.drag.${mode}.title`);
    }
    const selectedOption = dragModeInputs.find(input => input.checked)
      ?.closest('.drag-mode-option');
    if (
      dragPreview
      && selectedOption
      && dragPreview.previousElementSibling !== selectedOption
    ) selectedOption.after(dragPreview);
    dragAnimation?.setMode(mode);
  }

  function renderResizeMode() {
    const mode = getDraftBookmarkResizeMode();
    for (const input of resizeModeInputs) {
      input.checked = input.value === mode;
      input.closest('.drag-mode-option')?.classList.toggle(
        'is-selected',
        input.checked
      );
    }
    if (resizeModeSummary) {
      resizeModeSummary.textContent = t(`settingsModal.bookmark.resize.${mode}.title`);
    }
    const selectedOption = resizeModeInputs.find(input => input.checked)
      ?.closest('.drag-mode-option');
    if (
      resizePreview
      && selectedOption
      && resizePreview.previousElementSibling !== selectedOption
    ) selectedOption.after(resizePreview);
    resizeAnimation?.setMode(mode);
  }

  function syncUI() {
    renderDragMode();
    renderResizeMode();
    onRequestSaveStateUpdate();
  }

  deleteAllBtn.addEventListener('click', deleteAllBookmarks);
  importBtn.addEventListener('click', () => importInput.click());

  return {
    syncUI,
    destroy() {
      dragAnimation?.destroy();
      resizeAnimation?.destroy();
    }
  };
}

function initCollapsibleSection(section) {
  const toggle = section.querySelector('.settings-collapsible-toggle');
  const bodyId = toggle?.getAttribute('aria-controls');
  const body = bodyId ? document.getElementById(bodyId) : null;
  if (!toggle || !body) return;

  toggle.addEventListener('click', () => {
    const expanded = toggle.getAttribute('aria-expanded') === 'true';
    setSectionExpanded(section, toggle, body, !expanded);
  });
}

function collapseBehaviorSections() {
  for (const section of document.querySelectorAll('.bookmark-behavior-settings')) {
    const toggle = section.querySelector('.settings-collapsible-toggle');
    const bodyId = toggle?.getAttribute('aria-controls');
    const body = bodyId ? document.getElementById(bodyId) : null;
    if (!toggle || !body) continue;
    setSectionExpanded(section, toggle, body, false);
  }
}

function setSectionExpanded(section, toggle, body, expanded) {
  toggle.setAttribute('aria-expanded', String(expanded));
  body.hidden = !expanded;
  section.classList.toggle('is-expanded', expanded);
  section.classList.toggle('is-collapsed', !expanded);
}
