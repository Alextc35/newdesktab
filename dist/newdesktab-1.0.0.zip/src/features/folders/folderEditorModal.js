import {
  BOOKMARK_FOLDER_NAME_MAX_LENGTH,
  createBookmarkFolder,
  updateBookmarkFolder
} from './folderActions.js';
import { DEFAULT_FOLDER_STYLE } from '../../domain/folders/folderDefaults.js';
import { validateFolderDraft } from '../../domain/folders/folderModel.js';
import { t } from '../../platform/i18n/i18n.js';
import { getState, getStorageMode, requirePersistence, subscribe } from '../../state/appStore.js';
import { showAlert } from '../../shared/ui/alertModal.js';
import { flashError, flashSuccess } from '../../shared/ui/flash.js';
import { isDarkInterfaceActive } from '../../shared/ui/interfaceTheme.js';
import { getMaxVisibleCols, getMaxVisibleRows } from '../grid/gridLayout.js';
import {
  getImageInputValue,
  initLocalImageUpload,
  setLocalImageSyncNoticeVisibility,
  setImageInputValue
} from '../../shared/ui/localImageUpload.js';
import { createLockableInputController } from '../../shared/ui/lockableInput.js';
import { closeModal, isModalActive, openModal, registerModal } from '../../shared/ui/modalManager.js';
import { createEditorHistory } from '../../shared/ui/editorHistory.js';
import { setEditorTitle } from '../../shared/ui/editorTitle.js';
import { refreshCustomColorPickers } from '../../shared/ui/colorPicker.js';
import { initTabs } from '../../shared/ui/tabs.js';
import { createItemAppearanceEditor } from '../item-editor/itemAppearanceEditor.js';
import { ensurePanelFits } from '../../shared/ui/viewportMode.js';
import { applyFolderAppearance } from './folderAppearance.js';
import { createFolderVisual } from './folderVisual.js';

let initialized = false;
let iconId = null;
let iconColor = null;
/** @type {'create'|'edit'|null} */
let mode = null;
let activeFolderId = null;
let initialValue = null;
let draftHistory;
let modal;
let modalTitle;
let nameInput;
let noBackgroundInput;
let noOuterBackgroundInput;
let colorInput;
let outerColorInput;
let outerColorResetButton;
let outerBackgroundColor = null;
let showPreviewsInput;
let showNameInput;
let iconColorInput;
let imageInput;
let imageSourceField;
let imageSourceSelect;
let imageUrlField;
let localImageInput;
let localImageField;
let localColorInput;
let imageUploadInput;
let imageUploadButton;
let imageUploadNotice;
let textColorInput;
let preview;
let saveButton;
let densityToggle;
let nameError;
let imageError;
let imageController;
let submitting = false;
let appearanceEditor;
let previewBookmarks = [];

export function initFolderEditorModal() {
  if (initialized) return;

  modal = requiredEditorElement('edit-folder-modal');
  modalTitle = modal.querySelector('h2');
  nameInput = requiredEditorElement('folder-editor-name');
  noBackgroundInput = requiredEditorElement('folder-editor-no-background');
  noOuterBackgroundInput = requiredEditorElement('folder-editor-no-outer-background');
  colorInput = requiredEditorElement('folder-editor-color');
  outerColorInput = requiredEditorElement('folder-editor-outer-color');
  outerColorResetButton = requiredEditorElement('folder-editor-outer-color-reset');
  showPreviewsInput = requiredEditorElement('folder-editor-show-previews');
  showNameInput = requiredEditorElement('folder-editor-show-name');
  iconColorInput = requiredEditorElement('folder-editor-symbol-color');
  imageInput = requiredEditorElement('folder-editor-image');
  imageSourceField = requiredEditorElement('folder-editor-image-source-field');
  imageSourceSelect = requiredEditorElement('folder-editor-image-source');
  imageUrlField = requiredEditorElement('folder-editor-image-url-field');
  localImageInput = requiredEditorElement('folder-editor-image-local');
  localImageField = localImageInput.closest('.local-image-field');
  localColorInput = requiredEditorElement('folder-editor-local-color');
  imageUploadInput = requiredEditorElement('folder-editor-image-upload-input');
  imageUploadButton = requiredEditorElement('folder-editor-image-upload');
  imageUploadNotice = imageUploadButton?.parentElement?.querySelector('.local-image-notice');
  textColorInput = requiredEditorElement('folder-editor-text-color');
  preview = requiredEditorElement('folder-editor-preview');
  saveButton = requiredEditorElement('edit-folder-modal-save');
  densityToggle = requiredEditorElement('folder-modal-density-toggle');
  nameError = requiredEditorElement('folder-editor-name-error');
  imageError = requiredEditorElement('folder-editor-image-error');
  const stylePanel = requiredEditorElement('folder-editor-panel-style');
  const cancelButton = requiredEditorElement('edit-folder-modal-cancel');
  const imageToggleButton = requiredEditorElement('folder-editor-image-toggle');
  const imageCopyButton = requiredEditorElement('folder-editor-image-copy');
  const imageClearButton = requiredEditorElement('folder-editor-image-clear');
  const localImageClearButton = requiredEditorElement('folder-editor-image-local-clear');

  // Validate the static controls before rearranging the form or adding listeners.
  // A failed attempt must not leave an apparently initialized editor behind.
  imageController = createLockableInputController({
    input: imageInput,
    toggleBtn: imageToggleButton,
    copyBtn: imageCopyButton,
    clearBtn: imageClearButton,
    onChange: handleInput
  });

  appearanceEditor = createItemAppearanceEditor({
    root: modal,
    type: 'folder',
    stylePanel,
    getValue: currentValue,
    renderSample: value => createFolderPreviewCard(value),
    onApply: appearance => {
      populateForm({ ...currentValue(), ...appearance });
      handleInput();
    }
  });

  initTabs({
    root: modal,
    tabButtonSelector: '.edit-bookmark-modal-tab-btn',
    tabContentSelector: '.edit-bookmark-modal-tab-content'
  });

  for (const input of [nameInput, textColorInput]) {
    input.addEventListener('input', handleInput);
  }
  colorInput.addEventListener('input', () => {
    localColorInput.value = colorInput.value;
    handleInput();
  });
  localColorInput.addEventListener('input', () => {
    colorInput.value = localColorInput.value;
    handleInput();
  });
  iconColorInput.addEventListener('input', () => {
    iconColor = iconColorInput.value;
    handleInput();
  });
  for (const input of [
    noBackgroundInput, noOuterBackgroundInput,
    showPreviewsInput, showNameInput
  ]) {
    input.addEventListener('change', handleInput);
  }
  imageSourceSelect.addEventListener('change', handleInput);
  outerColorInput.addEventListener('input', () => {
    outerBackgroundColor = outerColorInput.value;
    handleInput();
  });
  outerColorResetButton.addEventListener('click', () => {
    outerBackgroundColor = null;
    outerColorInput.value = fallbackOuterBackgroundColor();
    handleInput();
  });
  initLocalImageUpload({
    button: imageUploadButton,
    fileInput: imageUploadInput,
    targetInput: localImageInput,
    clearButton: localImageClearButton,
    onChange: () => {
      imageSourceSelect.value = getImageInputValue(localImageInput) ? 'local' : 'url';
      handleInput();
    }
  });
  cancelButton.addEventListener('click', handleCancel);
  saveButton.addEventListener('click', handleSave);
  densityToggle.addEventListener('click', () => {
    setCreateCompactMode(!modal.classList.contains('is-add-compact'));
    requestAnimationFrame(() => nameInput.focus());
  });

  registerModal({
    id: 'folder-editor',
    element: modal,
    requiresWideViewport: true,
    closeOnEsc: true,
    closeOnOverlay: true,
    acceptOnEnter: true
  });
  draftHistory = createEditorHistory({
    root: modal, getValue: currentValue,
    applyValue: value => { populateForm(value); handleInput(); },
    isActive: () => isModalActive('folder-editor') && !submitting,
    onRestore: () => refreshCustomColorPickers(modal)
  });
  subscribe(state => { previewBookmarks = state.data.bookmarks; });
  initialized = true;
}

function requiredEditorElement(id) {
  const element = document.getElementById(id);
  if (!element) throw new Error(`Folder editor cannot initialize: missing #${id}`);
  return element;
}

/** Opens a compact new-folder draft that can expand into the full editor. */
export function openCreateFolder() {
  if (!initialized || !ensurePanelFits()) return;

  mode = 'create';
  activeFolderId = null;
  initialValue = editableFolderValue({ ...DEFAULT_FOLDER_STYLE, name: '' });
  populateForm(initialValue);
  setEditorTitle(modalTitle, 'folder.editor.createTitle', { creating: true });
  saveButton.textContent = t('buttons.add');
  setCreateCompactMode(true);
  prepareEditor();

  openModal('folder-editor', {
    onAccept: handleSave,
    onCancel: handleCancel,
    initialFocus: nameInput
  });
}

export function openFolderEditor(folderId) {
  if (!initialized || !ensurePanelFits()) return;
  const folder = getState().data.folders.find(item => item.id === folderId);
  if (!folder) return;

  mode = 'edit';
  activeFolderId = folderId;
  initialValue = editableFolderValue(folder);
  populateForm(initialValue);
  setEditorTitle(modalTitle, 'folder.editor.title');
  saveButton.textContent = t('buttons.save');
  setCreateCompactMode(false);
  prepareEditor();

  openModal('folder-editor', {
    onAccept: handleSave,
    onCancel: handleCancel,
    initialFocus: nameInput
  });
}

function populateForm(value) {
  iconId = value.iconId ?? null;
  iconColor = value.iconColor ?? null;
  nameInput.maxLength = BOOKMARK_FOLDER_NAME_MAX_LENGTH;
  nameInput.value = value.name;
  noBackgroundInput.checked = value.noBackground;
  noOuterBackgroundInput.checked = value.noOuterBackground;
  colorInput.value = value.backgroundColor;
  localColorInput.value = value.backgroundColor;
  outerBackgroundColor = value.outerBackgroundColor;
  outerColorInput.value = outerBackgroundColor || fallbackOuterBackgroundColor();
  showPreviewsInput.checked = value.showPreviews;
  showNameInput.checked = value.showName;
  imageSourceSelect.value = value.backgroundImageSource;
  setImageInputValue(imageInput, value.backgroundImageUrl);
  setImageInputValue(localImageInput, value.backgroundImageLocal);
  textColorInput.value = value.textColor;
  imageController.setLocked(value.backgroundImageUrlLocked);
}

function fallbackOuterBackgroundColor() {
  return isDarkInterfaceActive() ? '#0f172a' : '#f4f4f5';
}

function prepareEditor() {
  appearanceEditor?.refresh();
  setLocalImageSyncNoticeVisibility(imageUploadNotice, getStorageMode());
  clearErrors();
  syncStyleControls();
  activateGeneralTab();
  renderPreview();
  syncSaveButton();
  draftHistory.reset();
}

function handleInput() {
  clearErrors();
  syncStyleControls();
  renderPreview();
  syncSaveButton();
}

function currentValue() {
  return {
    iconId,
    iconColor,
    name: nameInput.value,
    noBackground: noBackgroundInput.checked,
    noOuterBackground: noOuterBackgroundInput.checked,
    backgroundColor: colorInput.value,
    outerBackgroundColor,
    showFolder: true,
    showPreviews: showPreviewsInput.checked,
    showName: showNameInput.checked,
    backgroundImageUrl: getImageInputValue(imageInput) || null,
    backgroundImageLocal: getImageInputValue(localImageInput) || null,
    backgroundImageSource: imageSourceSelect.value,
    backgroundImageUrlLocked: imageController?.isLocked() ?? false,
    textColor: textColorInput.value
  };
}

function editableFolderValue(folder) {
  const validation = validateFolderDraft(folder);
  return validation.value;
}

function isDirty() {
  if (!initialValue) return false;
  const current = currentValue();
  return current.name !== initialValue.name
    || current.iconId !== initialValue.iconId
    || current.iconColor !== initialValue.iconColor
    || current.noBackground !== initialValue.noBackground
    || current.noOuterBackground !== initialValue.noOuterBackground
    || current.backgroundColor !== initialValue.backgroundColor
    || current.outerBackgroundColor !== initialValue.outerBackgroundColor
    || current.showPreviews !== initialValue.showPreviews
    || current.showName !== initialValue.showName
    || current.backgroundImageUrl !== initialValue.backgroundImageUrl
    || current.backgroundImageLocal !== initialValue.backgroundImageLocal
    || current.backgroundImageSource !== initialValue.backgroundImageSource
    || current.backgroundImageUrlLocked !== initialValue.backgroundImageUrlLocked
    || current.textColor !== initialValue.textColor;
}

function syncStyleControls() {
  const hasLocalImage = Boolean(getImageInputValue(localImageInput));
  const activeSource = hasLocalImage && imageSourceSelect.value !== 'url' ? 'local' : 'url';
  imageSourceSelect.value = activeSource;
  imageSourceField.classList.toggle('is-hidden', !hasLocalImage);
  imageUrlField.classList.toggle('is-hidden', hasLocalImage && activeSource === 'local');
  localImageField.classList.toggle('is-hidden', !hasLocalImage || activeSource === 'url');
  colorInput.disabled = noBackgroundInput.checked;
  localColorInput.disabled = noBackgroundInput.checked || activeSource !== 'local';
  showPreviewsInput.disabled = Boolean(iconId);
  showPreviewsInput.closest('.checkbox-wrapper').hidden = Boolean(iconId);
  outerColorResetButton.disabled = outerBackgroundColor === null;
  outerColorInput.disabled = noOuterBackgroundInput.checked;
  textColorInput.disabled = !showNameInput.checked;
  iconColorInput.closest('.folder-symbol-color').hidden = !iconId;
  iconColorInput.disabled = !iconId;
  iconColorInput.value = iconColor || '#f8fafc';
  appearanceEditor?.sync();
}

function syncSaveButton() {
  if (submitting) {
    saveButton.disabled = true;
    return;
  }
  if (mode === 'create') {
    const hasName = currentValue().name.trim().length > 0;
    saveButton.disabled = !hasName;
    saveButton.classList.toggle('is-disabled', !hasName);
    saveButton.classList.remove('is-hidden');
    return;
  }

  const changed = isDirty();
  saveButton.disabled = !changed;
  saveButton.classList.remove('is-hidden');
  saveButton.classList.remove('is-disabled');
}

function renderPreview() {
  preview.replaceChildren(createFolderPreviewCard(currentValue()));
}

function createFolderPreviewCard(folder) {
  const bookmarks = activeFolderId
    ? previewBookmarks.filter(bookmark => bookmark.folderId === activeFolderId)
    : [];
  const count = bookmarks.length;
  const name = folder.name.trim() || t('folder.editor.previewName');
  const card = document.createElement('div');
  card.className = 'folder-editor-preview-card';
  card.setAttribute('role', 'img');
  card.setAttribute('aria-label', `${name}, ${t('folder.count', { count })}`);
  applyFolderAppearance(card, folder);

  const content = document.createElement('div');
  content.className = 'folder-card-content';
  content.append(createFolderVisual(folder, bookmarks));

  const caption = document.createElement('span');
  caption.className = 'folder-caption';
  const title = document.createElement('span');
  title.className = 'folder-title';
  title.textContent = name;
  caption.append(title);
  content.append(caption);
  card.append(content);
  return card;
}

async function handleSave() {
  if (submitting) return;
  if (mode === 'create') {
    await handleCreate();
    return;
  }
  if (!activeFolderId || !isDirty()) return;
  const result = validateFolderDraft(currentValue());
  if (!result.isValid) {
    renderErrors(result.errors);
    return;
  }

  submitting = true;
  saveButton.disabled = true;
  try {
    const updated = updateBookmarkFolder(activeFolderId, result.value);
    if (!updated) return;
    await requirePersistence();
    flashSuccess('flash.folder.updated');
    closeFolderEditor();
  } catch {
    flashError('settingsModal.sync.status.error');
  } finally {
    submitting = false;
    syncSaveButton();
  }
}

async function handleCreate() {
  const result = validateFolderDraft(currentValue());
  if (!result.isValid) {
    renderErrors(result.errors);
    return;
  }

  submitting = true;
  saveButton.disabled = true;
  try {
    const created = activeFolderId
      ? updateBookmarkFolder(activeFolderId, result.value)
      : createBookmarkFolder(result.value.name, {
        columns: getMaxVisibleCols(),
        rows: getMaxVisibleRows()
      }, result.value);
    if (!created) {
      closeFolderEditor();
      await new Promise(requestAnimationFrame);
      await showAlert(t('folder.noSpace'), { type: 'info' });
      return;
    }

    activeFolderId = created.id;
    await requirePersistence();
    flashSuccess('flash.folder.created');
    closeFolderEditor();
  } catch {
    flashError('settingsModal.sync.status.error');
  } finally {
    submitting = false;
    syncSaveButton();
    imageUploadInput.value = '';
  }
}

async function handleCancel() {
  if (isDirty()) {
    const confirmed = await showAlert(t(
      mode === 'create' ? 'alert.folder.createCancel' : 'alert.folder.cancel'
    ), { type: 'confirm' });
    if (!confirmed) return false;
  }
  closeFolderEditor();
  return true;
}

function renderErrors(errors) {
  clearErrors();
  if (errors.name) {
    nameInput.setAttribute('aria-invalid', 'true');
    nameError.textContent = t(`validation.folderName.${errors.name}`);
    nameError.classList.remove('is-hidden');
  }
  if (errors.backgroundImageUrl) {
    imageInput.setAttribute('aria-invalid', 'true');
    imageError.textContent = t(
      `validation.backgroundImageUrl.${errors.backgroundImageUrl}`
    );
    imageError.classList.remove('is-hidden');
  }
  appearanceEditor?.sync();
  const invalidInput = errors.name ? nameInput : errors.backgroundImageUrl ? imageInput : null;
  if (invalidInput) {
    const tab = errors.name ? 'general' : 'style';
    modal.querySelector(`[data-tab="folder-editor-panel-${tab}"]`)?.click();
    invalidInput.focus();
  }
}

function clearErrors() {
  nameInput.removeAttribute('aria-invalid');
  imageInput.removeAttribute('aria-invalid');
  for (const error of [nameError, imageError]) {
    error.textContent = '';
    error.classList.add('is-hidden');
  }
}

function activateGeneralTab() {
  for (const button of modal.querySelectorAll('.edit-bookmark-modal-tab-btn')) {
    const active = button.dataset.tab === 'folder-editor-panel-general';
    button.classList.toggle('active', active);
    button.setAttribute('aria-selected', String(active));
    button.tabIndex = active ? 0 : -1;
  }
  for (const panel of modal.querySelectorAll('.edit-bookmark-modal-tab-content')) {
    panel.classList.toggle('is-hidden', panel.id !== 'folder-editor-panel-general');
  }
}

function setCreateCompactMode(compact) {
  const isCreateMode = mode === 'create';
  const nextCompact = isCreateMode && compact;
  if (nextCompact) activateGeneralTab();

  modal.classList.toggle('is-add-compact', nextCompact);
  densityToggle.classList.toggle('is-hidden', !isCreateMode);
  densityToggle.setAttribute('aria-expanded', String(isCreateMode && !nextCompact));
  densityToggle.textContent = t(
    nextCompact ? 'addModal.advancedOptions' : 'addModal.compactView'
  );

  for (const element of modal.querySelectorAll(
    '.edit-bookmark-modal-tabs, .edit-bookmark-modal-preview-panel'
  )) {
    element.inert = nextCompact;
    if (nextCompact) element.setAttribute('aria-hidden', 'true');
    else element.removeAttribute('aria-hidden');
  }
}

function closeFolderEditor() {
  draftHistory.reset();
  modal.classList.remove('is-add-compact');
  densityToggle.classList.add('is-hidden');
  mode = null;
  activeFolderId = null;
  initialValue = null;
  closeModal('folder-editor');
}
