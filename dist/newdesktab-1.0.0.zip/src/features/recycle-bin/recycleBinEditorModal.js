import { t } from '../../platform/i18n/i18n.js';
import {
  normalizeRecycleBinStyle,
  validateRecycleBinStyle
} from '../../domain/recycle-bin/recycleBinModel.js';
import { updateRecycleBinAppearance } from './recycleBinActions.js';
import { getState, getStorageMode, requirePersistence } from '../../state/appStore.js';
import { showAlert } from '../../shared/ui/alertModal.js';
import { flashError, flashSuccess } from '../../shared/ui/flash.js';
import { isDarkInterfaceActive } from '../../shared/ui/interfaceTheme.js';
import {
  getImageInputValue,
  initLocalImageUpload,
  setImageInputValue,
  setLocalImageSyncNoticeVisibility
} from '../../shared/ui/localImageUpload.js';
import {
  applyRecycleBinAppearance,
  createRecycleBinGlyph
} from './recycleBinAppearance.js';
import { createLockableInputController } from '../../shared/ui/lockableInput.js';
import { closeModal, isModalActive, openModal, registerModal } from '../../shared/ui/modalManager.js';
import { createEditorHistory } from '../../shared/ui/editorHistory.js';
import { setEditorTitle } from '../../shared/ui/editorTitle.js';
import { refreshCustomColorPickers } from '../../shared/ui/colorPicker.js';
import { initTabs } from '../../shared/ui/tabs.js';
import { createItemAppearanceEditor } from '../item-editor/itemAppearanceEditor.js';
import { ensurePanelFits } from '../../shared/ui/viewportMode.js';
import { initCustomSelect, refreshCustomSelect } from '../../shared/ui/customSelect.js';
import { normalizeRecycleBinRetentionDays } from '../../domain/settings/recycleBinRetention.js';

let initialized = false;
let submitting = false;
let initialValue = null;
let draftHistory;
let modal;
let noBackgroundInput;
let backgroundColorInput;
let localColorInput;
let backgroundColorExplicit = false;
let imageInput;
let imageSourceField;
let imageSourceSelect;
let imageUrlField;
let localImageInput;
let localImageField;
let imageUploadInput;
let imageUploadButton;
let imageUploadNotice;
let imageError;
let imageController;
let iconColorInput;
let textColorInput;
let textColorExplicit = false;
let showNameInput;
let visibleInput;
let animateIconInput;
let retentionSelect;
let preview;
let saveButton;
let tabs;
let appearanceEditor;

export function initRecycleBinEditorModal() {
  if (initialized) return;
  initialized = true;

  modal = document.getElementById('edit-recycle-bin-modal');
  noBackgroundInput = document.getElementById('recycle-bin-editor-no-background');
  backgroundColorInput = document.getElementById('recycle-bin-editor-background-color');
  localColorInput = document.getElementById('recycle-bin-editor-local-color');
  imageInput = document.getElementById('recycle-bin-editor-image');
  imageSourceField = document.getElementById('recycle-bin-editor-image-source-field');
  imageSourceSelect = document.getElementById('recycle-bin-editor-image-source');
  imageUrlField = document.getElementById('recycle-bin-editor-image-url-field');
  localImageInput = document.getElementById('recycle-bin-editor-image-local');
  localImageField = localImageInput.closest('.local-image-field');
  imageUploadInput = document.getElementById('recycle-bin-editor-image-upload-input');
  imageUploadButton = document.getElementById('recycle-bin-editor-image-upload');
  imageUploadNotice = imageUploadButton?.parentElement?.querySelector('.local-image-notice');
  imageError = document.getElementById('recycle-bin-editor-image-error');
  iconColorInput = document.getElementById('recycle-bin-editor-icon-color');
  textColorInput = document.getElementById('recycle-bin-editor-text-color');
  showNameInput = document.getElementById('recycle-bin-editor-show-name');
  visibleInput = document.getElementById('recycle-bin-editor-visible');
  animateIconInput = document.getElementById('recycle-bin-editor-animate-icon');
  retentionSelect = document.getElementById('recycle-bin-editor-retention');
  initCustomSelect(retentionSelect);
  retentionSelect.addEventListener('change', handleInput);
  preview = document.getElementById('recycle-bin-editor-preview');
  saveButton = document.getElementById('edit-recycle-bin-modal-save');

  appearanceEditor = createItemAppearanceEditor({
    root: modal,
    type: 'recycleBin',
    stylePanel: document.getElementById('recycle-bin-editor-panel-style'),
    getValue: currentValue,
    renderSample: value => createRecycleBinPreviewCard(value),
    onApply: appearance => {
      setControlValues(appearance, visibleInput.checked);
      handleInput();
    }
  });

  tabs = initTabs({
    root: modal,
    tabButtonSelector: '.edit-bookmark-modal-tab-btn',
    tabContentSelector: '.edit-bookmark-modal-tab-content'
  });

  backgroundColorInput.addEventListener('input', () => {
    backgroundColorExplicit = true;
    localColorInput.value = backgroundColorInput.value;
    handleInput();
  });
  localColorInput.addEventListener('input', () => {
    backgroundColorExplicit = true;
    backgroundColorInput.value = localColorInput.value;
    handleInput();
  });
  iconColorInput.addEventListener('input', handleInput);
  textColorInput.addEventListener('input', () => {
    textColorExplicit = true;
    handleInput();
  });
  for (const input of [
    noBackgroundInput,
    showNameInput,
    visibleInput, animateIconInput
  ]) {
    input.addEventListener('change', handleInput);
  }
  imageSourceSelect.addEventListener('change', handleInput);
  imageController = createLockableInputController({
    input: imageInput,
    toggleBtn: document.getElementById('recycle-bin-editor-image-toggle'),
    copyBtn: document.getElementById('recycle-bin-editor-image-copy'),
    clearBtn: document.getElementById('recycle-bin-editor-image-clear'),
    onChange: handleInput
  });
  initLocalImageUpload({
    button: imageUploadButton,
    fileInput: imageUploadInput,
    targetInput: localImageInput,
    clearButton: document.getElementById('recycle-bin-editor-image-local-clear'),
    onChange: () => {
      imageSourceSelect.value = getImageInputValue(localImageInput) ? 'local' : 'url';
      handleInput();
    }
  });
  document.getElementById('edit-recycle-bin-modal-cancel').addEventListener('click', handleCancel);
  saveButton.addEventListener('click', handleSave);

  registerModal({
    id: 'recycle-bin-editor',
    element: modal,
    requiresWideViewport: true,
    closeOnEsc: true,
    closeOnOverlay: true,
    acceptOnEnter: true
  });
  draftHistory = createEditorHistory({
    root: modal, getValue: currentValue,
    applyValue: value => {
      setControlValues(value, value.showRecycleBin);
      retentionSelect.value = String(value.recycleBinRetentionDays);
      handleInput();
    },
    isActive: () => isModalActive('recycle-bin-editor') && !submitting,
    onRestore: () => refreshCustomColorPickers(modal)
  });
}

export function openRecycleBinEditor() {
  if (!ensurePanelFits()) return;
  setEditorTitle(modal.querySelector('h2'), 'recycleBin.editor.title');
  const { recycleBin, settings } = getState().data;
  const style = normalizeRecycleBinStyle(recycleBin);
  initialValue = { ...style, showRecycleBin: settings.showRecycleBin !== false,
    recycleBinRetentionDays: normalizeRecycleBinRetentionDays(settings.recycleBinRetentionDays) };

  setControlValues(style, initialValue.showRecycleBin);
  retentionSelect.value = String(initialValue.recycleBinRetentionDays);
  setLocalImageSyncNoticeVisibility(imageUploadNotice, getStorageMode());
  clearErrors();
  tabs.activate('recycle-bin-editor-panel-general');
  appearanceEditor?.refresh();
  syncControls();
  renderPreview();
  syncSaveButton();

  draftHistory.reset();
  openModal('recycle-bin-editor', {
    onAccept: handleSave,
    onCancel: handleCancel,
    initialFocus: visibleInput
  });
}

function handleInput() {
  clearErrors();
  syncControls();
  renderPreview();
  syncSaveButton();
}

function currentValue() {
  return {
    animateIcon: animateIconInput.checked,
    noBackground: noBackgroundInput.checked,
    backgroundColor: backgroundColorExplicit ? backgroundColorInput.value : null,
    backgroundImageUrl: getImageInputValue(imageInput) || null,
    backgroundImageLocal: getImageInputValue(localImageInput) || null,
    backgroundImageSource: imageSourceSelect.value,
    backgroundImageUrlLocked: imageController?.isLocked() ?? false,
    iconColor: iconColorInput.value,
    textColor: textColorExplicit ? textColorInput.value : null,
    showName: showNameInput.checked,
    showRecycleBin: visibleInput.checked,
    recycleBinRetentionDays: normalizeRecycleBinRetentionDays(retentionSelect.value)
  };
}

function syncControls() {
  refreshCustomSelect(retentionSelect);
  const hasLocalImage = Boolean(getImageInputValue(localImageInput));
  const activeSource = hasLocalImage && imageSourceSelect.value !== 'url' ? 'local' : 'url';
  imageSourceSelect.value = activeSource;
  imageSourceField.classList.toggle('is-hidden', !hasLocalImage);
  imageUrlField.classList.toggle('is-hidden', hasLocalImage && activeSource === 'local');
  localImageField.classList.toggle('is-hidden', !hasLocalImage || activeSource === 'url');
  backgroundColorInput.disabled = noBackgroundInput.checked;
  localColorInput.disabled = noBackgroundInput.checked || activeSource !== 'local';
  textColorInput.disabled = !showNameInput.checked;
  appearanceEditor?.sync();
}

function setControlValues(style, showRecycleBin) {
  const value = normalizeRecycleBinStyle(style);
  backgroundColorExplicit = Boolean(value.backgroundColor);
  textColorExplicit = Boolean(value.textColor);
  noBackgroundInput.checked = value.noBackground;
  backgroundColorInput.value = value.backgroundColor || fallbackBackgroundColor();
  localColorInput.value = backgroundColorInput.value;
  imageSourceSelect.value = value.backgroundImageSource;
  setImageInputValue(imageInput, value.backgroundImageUrl);
  setImageInputValue(localImageInput, value.backgroundImageLocal);
  iconColorInput.value = value.iconColor;
  textColorInput.value = value.textColor || fallbackTextColor();
  showNameInput.checked = value.showName;
  visibleInput.checked = showRecycleBin;
  animateIconInput.checked = value.animateIcon;
  imageController.setLocked(value.backgroundImageUrlLocked);
}

function fallbackBackgroundColor() {
  return isDarkInterfaceActive() ? '#0f172a' : '#e2e8f0';
}

function fallbackTextColor() {
  return isDarkInterfaceActive() ? '#f8fafc' : '#273244';
}

function isDirty() {
  return initialValue !== null
    && JSON.stringify(currentValue()) !== JSON.stringify(initialValue);
}

function syncSaveButton() {
  const changed = isDirty();
  saveButton.disabled = submitting || !changed;
  saveButton.classList.remove('is-hidden');
}

function renderPreview() {
  preview.replaceChildren(createRecycleBinPreviewCard(currentValue()));
}

function createRecycleBinPreviewCard(value) {
  const card = document.createElement('div');
  card.className = 'recycle-bin recycle-bin-editor-preview-card';
  applyRecycleBinAppearance(card, value);

  const content = document.createElement('div');
  content.className = 'recycle-bin-open';
  const caption = document.createElement('span');
  caption.className = 'recycle-bin-caption';
  const title = document.createElement('strong');
  title.textContent = t('recycleBin.title');
  caption.append(title);
  content.append(createRecycleBinGlyph(value), caption);
  card.append(content);
  return card;
}

async function handleSave() {
  if (submitting || !isDirty()) return;
  const draft = currentValue();
  const result = validateRecycleBinStyle(draft);
  if (!result.isValid) {
    renderErrors(result.errors);
    return;
  }

  saveButton.disabled = true;
  submitting = true;
  try {
    await updateRecycleBinAppearance({
      ...result.value,
      showRecycleBin: draft.showRecycleBin,
      recycleBinRetentionDays: draft.recycleBinRetentionDays
    });
    await requirePersistence();
    flashSuccess('flash.recycleBin.updated');
    closeRecycleBinEditor();
  } catch {
    flashError('settingsModal.sync.status.error');
  } finally {
    submitting = false;
    syncSaveButton();
  }
}

async function handleCancel() {
  if (isDirty()) {
    const confirmed = await showAlert(t('alert.recycleBin.cancel'), { type: 'confirm' });
    if (!confirmed) return false;
  }
  closeRecycleBinEditor();
  return true;
}

function closeRecycleBinEditor() {
  draftHistory.reset();
  initialValue = null;
  closeModal('recycle-bin-editor');
}

function renderErrors(errors) {
  clearErrors();
  if (errors.backgroundImageUrl) {
    imageInput.setAttribute('aria-invalid', 'true');
    imageError.textContent = t(
      `validation.backgroundImageUrl.${errors.backgroundImageUrl}`
    );
    imageError.classList.remove('is-hidden');
  }
  appearanceEditor?.sync();
  if (errors.backgroundImageUrl) {
    tabs.activate('recycle-bin-editor-panel-style');
    imageInput.focus();
  }
}

function clearErrors() {
  imageInput.removeAttribute('aria-invalid');
  imageError.textContent = '';
  imageError.classList.add('is-hidden');
}
