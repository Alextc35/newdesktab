import { DEFAULT_BOOKMARK_STYLE } from '../../domain/bookmarks/bookmarkDefaults.js';
import { DEFAULT_FOLDER_STYLE } from '../../domain/folders/folderDefaults.js';
import { DEFAULT_RECYCLE_BIN_STYLE } from '../../domain/recycle-bin/recycleBinDefaults.js';
import { applyI18n } from '../../platform/i18n/i18n.js';
import { openCustomColorPicker } from '../../shared/ui/colorPicker.js';
import { createIconPicker } from './iconPicker.js';
import { initAnimatedDisclosure } from '../../shared/ui/animatedDisclosure.js';

const DEFAULTS = {
  bookmark: DEFAULT_BOOKMARK_STYLE,
  folder: DEFAULT_FOLDER_STYLE,
  recycleBin: DEFAULT_RECYCLE_BIN_STYLE
};
const PALETTES = {
  original: null,
  card: { background: '#111827', text: '#ffffff' },
  midnight: { background: '#171717', text: '#f5f5f5', icon: '#a3a3a3' },
  paper: { background: '#f1f0ec', text: '#292524', icon: '#78716c' }
};
const CONTENT_FIELDS = {
  bookmark: ['iconId', 'iconColor', 'backgroundFavicon', 'showText', 'showFavicon', 'captionPosition', 'invertColorIcon'],
  folder: ['iconId', 'iconColor', 'showPreviews', 'showName'],
  recycleBin: ['showName', 'animateIcon']
};

function textForBlackOrWhiteBackground(background) {
  const color = typeof background === 'string' ? background.toLowerCase() : '';
  return color === '#ffffff' ? '#000000' : color === '#000000' ? '#ffffff' : null;
}

/** Appearance-only values: choosing a look never changes identity or grid layout. */
export function getItemAppearance(type, look = 'original', current = {}) {
  const defaults = DEFAULTS[type];
  if (!defaults || !Object.hasOwn(PALETTES, look) || (look === 'card' && type !== 'bookmark')) return null;
  const palette = PALETTES[look];
  if (!palette) return type === 'recycleBin'
    ? { ...defaults, animateIcon: current.animateIcon ?? defaults.animateIcon }
    : { ...defaults, iconId: current.iconId ?? null };
  const style = { ...defaults, noBackground: false, textColor: palette.text ?? defaults.textColor };
  for (const field of CONTENT_FIELDS[type]) {
    if (Object.hasOwn(current, field)) style[field] = current[field];
  }
  if (look === 'card') {
    style.backgroundColor = palette.background;
    style.backgroundFavicon = false;
    style.showText = true;
    return style;
  }
  if (type === 'folder') {
    style.noOuterBackground = false;
    style.outerBackgroundColor = palette.background;
    style.backgroundColor = palette.icon;
  } else {
    style.backgroundColor = palette.background;
    if (type === 'recycleBin') style.iconColor = palette.icon;
  }
  return style;
}

/** Shared quick looks and appearance reset for all item editors. */
export function createItemAppearanceEditor({ root, type, stylePanel, getValue, renderSample, renderOriginalIcon, onApply, signal }) {
  if (!stylePanel) return { sync() {}, destroy() {} };
  root.classList.add('item-appearance-editor');
  if (type === 'bookmark') root.classList.add('bookmark-appearance-editor');
  const abortController = new AbortController();
  const options = { signal: abortController.signal };
  signal?.addEventListener('abort', () => abortController.abort(), { once: true });
  const cardColorSelector = type === 'bookmark'
    ? '[data-field="backgroundColor"], [data-field="backgroundImageLocalColor"]'
    : type === 'folder' ? '#folder-editor-outer-color'
      : '#recycle-bin-editor-background-color, #recycle-bin-editor-local-color';
  const textColorInput = root.querySelector(type === 'bookmark' ? '[data-field="textColor"]'
    : type === 'folder' ? '#folder-editor-text-color' : '#recycle-bin-editor-text-color');
  root.addEventListener('input', event => {
    if (!event.target.matches(cardColorSelector)) return;
    const color = textForBlackOrWhiteBackground(event.target.value);
    if (!color || !textColorInput || textColorInput.value === color) return;
    textColorInput.value = color;
    textColorInput.dispatchEvent(new Event('input', { bubbles: true }));
  }, options);
  const section = document.createElement('section');
  section.className = 'editor-looks';
  const heading = document.createElement('div');
  heading.className = 'editor-section-heading';
  const title = document.createElement('h3');
  title.dataset.i18n = 'itemEditor.looks';
  const status = document.createElement('span');
  status.className = 'editor-look-status';
  status.dataset.i18n = 'itemEditor.custom';
  heading.append(title, status);
  const looks = document.createElement('div');
  looks.className = 'editor-look-options';
  const availableLooks = Object.keys(PALETTES).filter(look => type === 'bookmark' || look !== 'card');
  looks.style.setProperty('--editor-look-count', String(availableLooks.length));
  looks.setAttribute('role', 'group');
  looks.dataset.i18nAriaLabel = 'itemEditor.looks';

  for (const look of availableLooks) {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'editor-look';
    button.dataset.appearanceLook = look;
    button.setAttribute('aria-pressed', 'false');
    const sample = document.createElement('span');
    sample.className = `editor-look-sample editor-look-sample-${look}`;
    sample.setAttribute('aria-hidden', 'true');
    const label = document.createElement('span');
    label.dataset.i18n = `itemEditor.look.${look}`;
    button.append(sample, label);
    button.addEventListener('click', () => onApply(getItemAppearance(type, look, getValue())), options);
    looks.append(button);
  }
  section.append(heading, looks);
  stylePanel?.prepend(section);

  const findPanel = name => root.querySelector(`[data-tab-panel="${name}"], [id$="-panel-${name}"]`);
  const group = name => {
    const element = document.createElement('section');
    element.className = `editor-control-group editor-${name}-group`;
    const title = document.createElement('h3');
    title.dataset.i18n = `itemEditor.section.${name}`;
    element.append(title);
    return element;
  };
  const background = group('card');
  const content = document.createElement('div');
  content.className = 'editor-content-groups';
  const groups = {};
  for (const name of ['icon', 'text']) {
    const panel = findPanel(name);
    if (!panel || !stylePanel) continue;
    const controls = group(name);
    controls.append(...panel.childNodes);
    panel.remove();
    root.querySelector(`[data-tab-button="${name}"], [data-tab$="-panel-${name}"]`)?.remove();
    content.append(controls);
    groups[name] = controls;
  }
  const iconPicker = groups.icon && type !== 'recycleBin' ? createIconPicker({
    type, getValue, renderOriginalIcon,
    onSelect: iconId => onApply({
      iconId,
      ...(type === 'folder' && !iconId ? { showPreviews: false } : {}),
      [type === 'bookmark' ? 'showFavicon' : type === 'folder' ? 'showFolder' : 'showIcon']: true
    }),
    signal: abortController.signal
  }) : null;
  if (iconPicker) groups.icon.firstElementChild.after(iconPicker.element);
  const bookmarkIconColorRow = type === 'bookmark'
    ? groups.icon?.querySelector('[data-field="iconColor"]')?.closest('.edit-bookmark-modal-color-options') : null;
  if (iconPicker && bookmarkIconColorRow) {
    const positionRow = groups.icon.querySelector('.editor-caption-position');
    (positionRow ?? iconPicker.element).after(bookmarkIconColorRow);
  }

  // Card/folder color is independent of the image source and URL lock.
  const colorInput = root.querySelector(type === 'bookmark'
    ? '[data-field="backgroundColor"]'
    : type === 'folder' ? '#folder-editor-color' : '#recycle-bin-editor-background-color');
  const colorWrapper = colorInput?.closest('.background-image-color');
  if (colorWrapper) {
    const transparency = stylePanel?.querySelector(type === 'bookmark'
      ? '[data-field="noBackground"]' : type === 'folder'
        ? '#folder-editor-no-background' : '#recycle-bin-editor-no-background');
    const row = document.createElement('div');
    row.className = 'editor-background-controls';
    if (transparency) row.append(transparency.closest('.checkbox-wrapper'));
    row.append(colorInput);
    colorWrapper.remove();
    if (type === 'folder') {
      groups.icon?.append(row);
      const outerToggle = root.querySelector('#folder-editor-no-outer-background')?.closest('.checkbox-wrapper');
      const outerColor = root.querySelector('#folder-editor-outer-color')?.closest('.edit-bookmark-modal-color-options');
      const outerRow = document.createElement('div');
      outerRow.className = 'editor-background-controls';
      if (outerToggle) outerRow.append(outerToggle);
      if (outerColor) outerRow.append(outerColor);
      background.append(outerRow);
    } else background.append(row);
  }
  const imageFields = root.querySelector(type === 'bookmark'
    ? '[data-field="backgroundImageUrlField"]'
    : type === 'folder' ? '#folder-editor-image-url-field' : '#recycle-bin-editor-image-url-field')?.parentElement;
  let imageDetails;
  let imageSummary;
  let imageDisclosure;
  if (imageFields && stylePanel) {
    imageDetails = document.createElement('details');
    imageDetails.className = 'editor-image-section';
    const summary = document.createElement('summary');
    imageSummary = document.createElement('span');
    imageSummary.dataset.i18n = 'itemEditor.addImage';
    summary.append(imageSummary);
    const imageContent = document.createElement('div');
    imageContent.className = 'editor-image-content';
    imageContent.append(imageFields);
    imageDetails.append(summary, imageContent);
    const invertBackground = root.querySelector('[data-field="invertBg"]')?.closest('.checkbox-wrapper');
    if (invertBackground) imageFields.append(invertBackground);
    imageDisclosure = initAnimatedDisclosure(imageDetails, imageContent, { signal: abortController.signal });
  }
  if (stylePanel) {
    stylePanel.append(background, content);
    if (imageDetails) stylePanel.append(imageDetails);
  }

  const colorChips = [];
  for (const input of root.querySelectorAll('input[type="color"]:not(.local-image-field input)')) {
    const chip = document.createElement('div');
    chip.className = 'editor-color-chip';
    const code = document.createElement('button');
    code.type = 'button';
    code.className = 'editor-color-code';
    code.tabIndex = -1;
    input.before(chip);
    chip.append(input, code);
    code.addEventListener('click', () => openCustomColorPicker(input, { anchor: chip, returnFocusTo: input }), options);
    colorChips.push({ input, code, chip });
  }
  for (const action of root.querySelectorAll('.input-action')) {
    const key = action.classList.contains('input-toggle') ? 'lock'
      : action.classList.contains('input-copy') ? 'copy' : 'clear';
    if (!action.hasAttribute('data-i18n-aria-label')) action.dataset.i18nAriaLabel = `itemEditor.${key}`;
  }

  const header = root.closest('.modal')?.querySelector('.edit-bookmark-modal-header');
  if (header && !header.querySelector('.editor-description')) {
    const description = document.createElement('p');
    description.className = 'editor-description';
    description.dataset.i18n = 'itemEditor.description';
    header.append(description);
  }

  const reset = document.createElement('button');
  reset.type = 'button';
  reset.className = 'btn btn-ghost editor-reset-appearance';
  reset.dataset.i18n = 'itemEditor.reset';
  reset.addEventListener('click', () => onApply(getItemAppearance(type, 'original', type === 'recycleBin' ? getValue() : {})), options);
  // The bookmark editor owns a reusable form; its footer belongs to the modal.
  const actions = root.querySelector('.modal-actions') || root.closest('.modal')?.querySelector('.modal-actions');
  actions?.prepend(reset);
  applyI18n(root);
  if (header) applyI18n(header);
  if (actions) applyI18n(actions);

  let sampleSignature;
  let lastImage;
  function sync() {
    const value = getValue();
    iconPicker?.sync();
    const signature = JSON.stringify([value.name, value.url, ...CONTENT_FIELDS[type].map(key => value[key])]);
    let selected = null;
    for (const button of looks.children) {
      const appearance = getItemAppearance(type, button.dataset.appearanceLook, value);
      const matches = Object.entries(appearance).every(([key, expected]) => value[key] === expected);
      button.setAttribute('aria-pressed', String(matches));
      if (matches) selected = button;
      if (renderSample && signature !== sampleSignature) {
        const card = renderSample({ ...value, ...appearance });
        card.classList.add('editor-look-item');
        for (const link of card.querySelectorAll('a')) {
          link.removeAttribute('href');
          link.tabIndex = -1;
        }
        button.querySelector('.editor-look-sample').replaceChildren(card);
      }
    }
    sampleSignature = signature;
    status.classList.toggle('is-hidden', Boolean(selected));
    reset.disabled = Object.entries(DEFAULTS[type]).every(([key, expected]) => value[key] === expected);
    if (type === 'bookmark') {
      root.querySelector('[data-field="showFavicon"]')?.closest('.checkbox-wrapper')
        ?.classList.toggle('is-hidden', value.backgroundFavicon);
      const iconColorRow = root.querySelector('[data-field="iconColor"]')?.closest('.edit-bookmark-modal-color-options');
      if (iconColorRow) iconColorRow.hidden = !value.iconId;
    }
    for (const { input, code, chip } of colorChips) {
      code.textContent = input.value.toUpperCase();
      code.disabled = input.disabled;
      code.setAttribute('aria-label', input.getAttribute('aria-label') || input.labels?.[0]?.textContent || code.textContent);
      chip.classList.toggle('is-disabled', input.disabled);
    }
    if (imageDetails) {
      const activeImage = value.backgroundImageSource === 'local' ? value.backgroundImageLocal : value.backgroundImageUrl;
      if (activeImage && activeImage !== lastImage) imageDisclosure.setOpen(true);
      lastImage = activeImage;
      imageSummary.dataset.i18n = activeImage ? 'itemEditor.changeImage' : 'itemEditor.addImage';
      applyI18n(imageDetails.querySelector('summary'));
      if (imageFields.querySelector('[aria-invalid="true"]')) imageDisclosure.setOpen(true);
    }
  }

  sync();
  return {
    sync,
    refresh() {
      if (iconPicker) iconPicker.element.open = false;
      sampleSignature = undefined;
      lastImage = undefined;
      imageDisclosure?.setOpen(false);
      sync();
    },
    destroy() {
      abortController.abort();
      reset.remove();
      section.remove();
    }
  };
}
