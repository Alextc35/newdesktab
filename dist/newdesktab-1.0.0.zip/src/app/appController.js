import { debug } from '../shared/diagnostics/debug.js';
import { changeLanguage } from '../platform/i18n/i18n.js';
import { applyInterfaceTheme } from '../shared/ui/interfaceTheme.js';
import { applyPageTheme } from '../shared/ui/pageTheme.js';
import {
  enableGridEditing,
  isLatestGridRender,
  renderGrid,
  trackGridRender
} from '../features/grid/gridRenderer.js';
import { clearGridItemSelection } from '../features/grid/gridSelection.js';
import { preloadLocalImages } from '../platform/images/localImages.js';
import { preloadLocalVideos } from '../platform/images/localVideos.js';
import {
  syncKeyboardShortcutAccessibility
} from '../features/keyboard/keyboardShortcutController.js';
import { updateAppShellEditing } from './appShell.js';
import { detectApplicationChanges } from './appStateChanges.js';
import { getStorageMode } from '../state/appStore.js';

/**
 * Coordinates application-wide UI effects caused by store transitions. Domain
 * commands stay in their features; this controller only routes state changes
 * to the relevant presentation and platform boundaries.
 */
export function createAppController({ container }) {
  let lastStorageMode;
  const applyCurrentPageTheme = settings => {
    const workspace = settings.bookmarkGroups?.find(item => (
      item.id === settings.activeBookmarkGroupId
    )) ?? (settings.activeBookmarkGroupId === null ? settings.mainWorkspace : null);
    const workspaceMedia = workspace?.backgroundMedia?.length
      ? workspace.backgroundMedia
      : workspace?.backgroundImageUrl || workspace?.backgroundImageLocal
        ? [{ id: `workspace-${settings.activeBookmarkGroupId ?? 'main'}`, type: 'image',
          backgroundImageUrl: workspace.backgroundImageUrl,
          backgroundImageLocal: workspace.backgroundImageLocal,
          backgroundImageSource: workspace.backgroundImageSource,
          backgroundColor: settings.theme.backgroundImageColor }]
        : [];
    const hasWorkspaceWallpaper = workspaceMedia.length > 0;
    const usesWorkspaceTheme = Boolean(workspace && workspace.themeEnabled !== false);
    const themeSettings = usesWorkspaceTheme
      ? {
          ...settings,
          theme: {
            ...settings.theme,
            backgroundDefault: !workspace.backgroundSolid && !hasWorkspaceWallpaper,
            backgroundSolid: workspace.backgroundSolid === true,
            backgroundColor: workspace.backgroundColor ?? settings.theme.backgroundColor,
            backgroundMedia: workspaceMedia,
            backgroundRotationSeconds: workspace.backgroundSolid
              ? 0 : workspace.backgroundRotationSeconds ?? 0,
            backgroundImageUrl: null,
            backgroundImageLocal: null
          }
        }
      : settings;
    applyPageTheme(themeSettings, {
      includeFallback: hasWorkspaceWallpaper || getStorageMode() === 'sync'
    });
  };
  return Object.freeze({
    handleStateChange(state, previousState) {
      const storageMode = getStorageMode();
      const modeChanged = lastStorageMode !== undefined && storageMode !== lastStorageMode;
      lastStorageMode = storageMode;
      if (!previousState) {
        applyPanelVisibility(state.data.settings);
        applyCurrentPageTheme(state.data.settings);
        updateAppShellEditing(state.ui.isEditing);
        const trace = debug.start('Initial grid render');
        renderGrid(container, state);
        trace.end();
        return;
      }

      const changes = detectApplicationChanges(state, previousState);
      if (modeChanged) applyCurrentPageTheme(state.data.settings);

      if (changes.editing && !state.ui.isEditing) {
        clearGridItemSelection();
      }

      if (changes.settings) {
        applyPanelVisibility(state.data.settings);
        applyInterfaceTheme(state.data.settings.interfaceTheme);
        void changeLanguage(state.data.settings);
        syncKeyboardShortcutAccessibility(state.data.settings.keyboardShortcuts);
      }

      if (changes.grid) {
        renderChangedGrid(container, state, changes.settings, applyCurrentPageTheme);
      } else if (changes.editing) {
        if (state.ui.isEditing) enableGridEditing(container);
        else renderGrid(container);
      }

      if (changes.editing) updateAppShellEditing(state.ui.isEditing);
    }
  });
}

function applyPanelVisibility(settings) {
  document.getElementById('floating-menu').hidden = settings.showLauncher === false;
  document.getElementById('workspace-toolbar').hidden = settings.showWorkspaceToolbar === false;
}

function renderChangedGrid(container, state, settingsChanged, applyCurrentPageTheme) {
  const trace = debug.start('Render grid', {
    bookmarks: state.data.bookmarks.length,
    folders: state.data.folders.length,
    widgets: state.data.widgets.length
  });
  const rendering = Promise.all([preloadLocalImages(state.data), preloadLocalVideos(state.data)]).then(() => {
    if (!isLatestGridRender(container, rendering)) {
      trace.end({ superseded: true });
      return;
    }
    trace.mark('Resolve local images');
    if (settingsChanged) applyCurrentPageTheme(state.data.settings);
    renderGrid(container);
    trace.mark('Build grid DOM');
    trace.end();
  }).catch(error => {
    if (!isLatestGridRender(container, rendering)) {
      trace.end({ superseded: true });
      return;
    }
    trace.end({ status: 'error', error: error.message });
    console.error('[LOCAL_IMAGE] Could not load local image:', error);
    if (settingsChanged) applyCurrentPageTheme(state.data.settings);
    renderGrid(container);
  });
  trackGridRender(container, rendering);
}
