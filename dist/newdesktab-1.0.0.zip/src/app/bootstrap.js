import { debug } from '../shared/diagnostics/debug.js';
import { finishDebugStartup, initDebugTools } from './applicationDiagnostics.js';
import { initI18n } from '../platform/i18n/i18n.js';
import { applyInterfaceTheme } from '../shared/ui/interfaceTheme.js';
import {
  getState,
  getSyncCompatibility,
  hydrateStore,
  subscribe,
  subscribeToRemoteSyncUpdates
} from '../state/appStore.js';
import {
  ensureRecycleBinPosition,
  purgeExpiredRecycleBinEntries
} from '../features/recycle-bin/recycleBinActions.js';
import { initRecycleBinEditorModal } from '../features/recycle-bin/recycleBinEditorModal.js';
import { initRecycleBinModal } from '../features/recycle-bin/recycleBinModal.js';
import { initBookmarkModal, openAddBookmark } from '../features/bookmarks/bookmarkModal.js';
import { initOnboarding } from '../features/onboarding/onboarding.js';
import { initHelp } from '../features/help/help.js';
import { initReleaseNotes } from '../features/release-notes/releaseNotes.js';
import { initFolderController } from '../features/folders/folderController.js';
import { initFolderEditorModal } from '../features/folders/folderEditorModal.js';
import { initFolderModal } from '../features/folders/folderModal.js';
import { initHistoryControls } from '../features/history/historyControls.js';
import { initSearchModal } from '../features/search/searchModal.js';
import { initSettingsModal } from '../features/settings/settingsModal.js';
import { initWorkspaceToolbar } from '../features/workspaces/workspaceToolbar.js';
import { initWorkspaceSettingsModal } from '../features/workspaces/workspaceSettingsModal.js';
import { preloadLocalImages } from '../platform/images/localImages.js';
import { preloadLocalVideos } from '../platform/images/localVideos.js';
import { initGridBulkActions } from '../features/grid/gridBulkActions.js';
import { initPersistenceFeedback } from '../features/persistence/persistedAction.js';
import { initGridKeyboardNavigation } from '../features/grid/gridKeyboardController.js';
import { initGridKeyboardMovement } from '../features/grid/gridKeyboardMovement.js';
import { initAlertModal } from '../shared/ui/alertModal.js';
import { initCustomColorPickers } from '../shared/ui/colorPicker.js';
import { flashInfo } from '../shared/ui/flash.js';
import { initFloatingMenu } from '../features/launcher/floatingMenu.js';
import { initKeyboardShortcuts } from '../features/keyboard/keyboardShortcutController.js';
import { initAppShell } from './appShell.js';
import { initializeWidgets } from '../widgets/widgetRegistry.js';
import { initWidgetCatalog } from '../widgets/widgetCatalog.js';
import { createAppController } from './appController.js';
import { registerGridItemTypes } from './registerGridItemTypes.js';

const RECYCLE_BIN_PURGE_INTERVAL_MS = 60 * 60 * 1000;

/** Starts NewDeskTab and reports bootstrap failures at the application boundary. */
export async function startApplication() {
  const startedAt = performance.now();
  const trace = debug.start('Initial load');

  try {
    await bootstrapApplication({ trace, startedAt });
  } catch (error) {
    trace.end({ status: 'error', error: error.message });
    // Chrome's extension error list otherwise records only this catch site,
    // losing the original failing control and its initialization stack.
    console.error('[NewDeskTab] Could not initialize the page:\n' + (error.stack || String(error)));
  }
}

/**
 * Composes the bundled features, hydrates state and connects UI controllers.
 * Ordering is intentional: state and localization are ready before UI setup.
 */
export async function bootstrapApplication({ trace, startedAt }) {
  const elements = getApplicationElements();
  registerGridItemTypes();

  await hydrateStore();
  purgeExpiredRecycleBinEntries();
  ensureRecycleBinPosition();
  setInterval(purgeExpiredRecycleBinEntries, RECYCLE_BIN_PURGE_INTERVAL_MS);
  trace.mark('Load and migrate data');

  applyInterfaceTheme(getState().data.settings.interfaceTheme);
  await preloadLocalImages(getState().data);
  await preloadLocalVideos(getState().data);
  trace.mark('Load local images');

  await initI18n(getState().data.settings);
  trace.mark('Load language');

  const appController = createAppController({ container: elements.container });
  subscribe(appController.handleStateChange);
  subscribeToRemoteSyncUpdates(event => {
    if (event.type === 'deleted') {
      flashInfo('flash.sync.deletedFromOtherDevice', 6000);
      return;
    }
    ensureRecycleBinPosition();
    flashInfo('flash.sync.updatedFromOtherDevice', 4000);
  });

  initializeUserInterface(elements);
  const releaseNotes = initReleaseNotes();
  const help = initHelp();
  const onboarding = initOnboarding({ onOpenManual: help.openManual, onAddBookmark: () => {
    document.getElementById('add-toggle').focus({ preventScroll: true });
    openAddBookmark();
  } });
  void releaseNotes.offerUpdate().then(async () => {
    await onboarding.offerWelcome();
    help.startDailyTips();
  });

  if (getSyncCompatibility()) {
    flashInfo('flash.sync.versionBlocked', 8000);
  }

  trace.mark('Initialize UI');
  initDebugTools();
  void finishDebugStartup(trace, startedAt).catch(error => {
    debug.info('Could not complete the startup report', { error: error.message });
  });
}

function getApplicationElements() {
  return {
    container: document.getElementById('bookmark-container'),
    gridOverlay: document.getElementById('grid-overlay'),
    toggleButton: document.getElementById('edit-toggle-mode')
  };
}

function initializeUserInterface({ container, gridOverlay, toggleButton }) {
  initPersistenceFeedback();
  initCustomColorPickers(document);
  initAppShell({ container, gridOverlay, toggleButton });
  initializeWidgets({
    modalHost: document.body
  });
  initWidgetCatalog({
    launcherButton: document.getElementById('add-widgets'),
    modalHost: document.body
  });
  initFloatingMenu();
  initModals();
  initHistoryControls();
  initWorkspaceSettingsModal();
  initWorkspaceToolbar();
  initGridBulkActions();
  initGridKeyboardNavigation(container);
  initGridKeyboardMovement();
  initFolderController();
  initKeyboardShortcuts();
}

function initModals() {
  initAlertModal();
  initSearchModal();
  initFolderModal();
  initFolderEditorModal();
  initRecycleBinModal();
  initRecycleBinEditorModal();
  initSettingsModal();
  initBookmarkModal();
}
