/**
 * Structural contract shared by every item placed on the main grid.
 * Feature adapters supply the item type at runtime so existing persisted data
 * does not need a discriminator migration.
 *
 * @typedef {Object} GridItem
 * @property {string} id
 * @property {number} gx
 * @property {number} gy
 * @property {number} w
 * @property {number} h
 * @property {string|null} groupId
 */

/**
 * Common persisted envelope for a statically bundled widget. Its `config`
 * object is private to the widget implementation identified by `type`.
 *
 * @typedef {GridItem & {
 *   type: string,
 *   version: number,
 *   config: Object,
 *   createdAt: number,
 *   updatedAt: number
 * }} WidgetInstance
 */

/**
 * @typedef {Object} Bookmark
 * @property {string|null} iconId Bundled category icon; null uses the site's favicon.
 * @property {string|null} iconColor Null keeps the icon's automatic color.
 * @property {string} id
 * @property {string} name
 * @property {string} url
 * @property {boolean} urlLocked
 * @property {number} gx
 * @property {number} gy
 * @property {number} w
 * @property {number} h
 * @property {string|null} groupId
 * @property {string|null} folderId
 * @property {string|null} backgroundImageUrl
 * @property {string|null} backgroundImageLocal
 * @property {'local'|'url'} backgroundImageSource
 * @property {boolean} backgroundImageUrlLocked
 * @property {boolean} backgroundFavicon
 * @property {boolean} invertColorBg
 * @property {boolean} noBackground
 * @property {string} backgroundColor
 * @property {boolean} showText
 * @property {string} textColor
 * @property {boolean} showFavicon
 * @property {'left'|'right'} captionPosition Position of the small icon and name caption.
 * @property {boolean} invertColorIcon
 * @property {number} createdAt
 * @property {number} updatedAt
 */

/**
 * @typedef {Object} BookmarkFolder
 * @property {string|null} iconId Bundled category icon; null uses folder artwork.
 * @property {string} id
 * @property {string} name
 * @property {number} gx
 * @property {number} gy
 * @property {number} w
 * @property {number} h
 * @property {string|null} groupId
 * @property {string|null} parentId Null places the folder on its workspace desktop.
 * @property {boolean} noBackground
 * @property {string} backgroundColor
 * @property {string|null} outerBackgroundColor Null keeps the automatic tile gradient.
 * @property {boolean} noOuterBackground Whether the outer tile is transparent.
 * @property {string|null} backgroundImageUrl
 * @property {string|null} backgroundImageLocal
 * @property {'local'|'url'} backgroundImageSource
 * @property {boolean} backgroundImageUrlLocked
 * @property {string} textColor
 * @property {boolean} showFolder Legacy field, normalized to true; folders always show their silhouette.
 * @property {boolean} showPreviews
 * @property {boolean} showName
 * @property {string|null} iconColor Null selects a contrasting symbol color.
 * @property {number} createdAt
 * @property {number} updatedAt
 */

/**
 * @typedef {Omit<Bookmark, 'id'> & {id?: string}} BookmarkDraft
 */

/**
 * @typedef {Object} BookmarkPreset
 * @property {string|null} iconId
 * @property {string|null} iconColor
 * @property {string|null} backgroundImageUrl
 * @property {string|null} backgroundImageLocal
 * @property {'local'|'url'} backgroundImageSource
 * @property {boolean} backgroundImageUrlLocked
 * @property {boolean} backgroundFavicon
 * @property {boolean} invertColorBg
 * @property {boolean} noBackground
 * @property {string} backgroundColor
 * @property {boolean} showText
 * @property {string} textColor
 * @property {boolean} showFavicon
 * @property {'left'|'right'} captionPosition
 * @property {boolean} invertColorIcon
 */

/**
 * @typedef {Object} Settings
 * @property {string} language - 'system' or a shipped locale from LANGUAGE_CATALOG.
 * @property {'system'|'light'|'dark'} interfaceTheme
 * @property {'none'|'cascade'|'relocate'} bookmarkDragMode
 * @property {'smooth'|'none'} bookmarkResizeMode
 * @property {'fit'|'relative'} windowResizeMode
 * @property {{toggleEditing: string|null, addBookmark: string|null, addFolder: string|null, openWidgets: string|null, openSettings: string|null}} keyboardShortcuts
 * @property {Object} theme
 * @property {boolean} theme.backgroundDefault
 * @property {boolean} theme.backgroundSolid
 * @property {string} theme.backgroundColor
 * @property {string} theme.backgroundImageColor
 * @property {string|null} theme.backgroundImageUrl
 * @property {string|null} theme.backgroundImageLocal
 * @property {'local'|'url'} theme.backgroundImageSource
 * @property {boolean} theme.backgroundImageUrlLocked
 * @property {'image'|'video'} theme.backgroundPrimaryType
 * @property {{url: string|null, local: string|null, source: 'local'|'url'}} theme.backgroundVideo
 * @property {Array<{id: string, type: 'image'|'video', url?: string|null, local?: string|null, backgroundImageUrl?: string|null, backgroundImageLocal?: string|null}>} theme.backgroundMedia
 * @property {number} theme.backgroundRotationSeconds
 * @property {BookmarkPreset} bookmarkDefault
 * @property {Array<{id: string, name: string, style: BookmarkPreset}>} bookmarkPresets
 * @property {Workspace[]} bookmarkGroups Legacy persisted field for workspaces.
 * @property {{name:string|null, backgroundImageUrl:string|null, backgroundImageLocal:string|null, backgroundImageSource:'url'|'local', backgroundImageUrlLocked:boolean, backgroundMedia:Array<{id:string,type:'image'|'video'}>, backgroundRotationSeconds:number}} mainWorkspace Editable name and image settings for Main.
 * @property {string|null} activeBookmarkGroupId
 * @property {boolean} showRecycleBin
 * @property {boolean} showLauncher
 * @property {boolean} showWorkspaceToolbar
 * @property {number} recycleBinRetentionDays Zero means items never expire.
 */

/**
 * @typedef {Object} Workspace
 * @property {string} id
 * @property {string} name
 * @property {string|null} backgroundImageUrl
 * @property {string|null} backgroundImageLocal
 * @property {'url'|'local'} backgroundImageSource
 * @property {boolean} backgroundImageUrlLocked
 * @property {Array<{id:string,type:'image'|'video'}>} backgroundMedia
 * @property {number} backgroundRotationSeconds
 */

/**
 * @typedef {Object} RecycleBin
 * @property {boolean} animateIcon Whether interaction animates the bin lid.
 * @property {string} id
 * @property {number} gx
 * @property {number} gy
 * @property {number} w
 * @property {number} h
 * @property {boolean} noBackground
 * @property {string|null} backgroundColor
 * @property {string|null} backgroundImageUrl
 * @property {string|null} backgroundImageLocal
 * @property {'local'|'url'} backgroundImageSource
 * @property {boolean} backgroundImageUrlLocked
 * @property {string} iconColor
 * @property {string|null} textColor
 * @property {boolean} showName
 * @property {null} groupId
 * @property {number} updatedAt
 */

/**
 * @typedef {Object} BookmarkTrashEntry
 * @property {string} id
 * @property {'bookmark'} type
 * @property {number} deletedAt
 * @property {Bookmark} bookmark
 */

/**
 * @typedef {Object} FolderTrashEntry
 * @property {string} id
 * @property {'folder'} type
 * @property {number} deletedAt
 * @property {BookmarkFolder} folder
 * @property {BookmarkFolder[]} [folders] Descendant folders retained with the root.
 * @property {Bookmark[]} bookmarks
 */

/**
 * @typedef {Object} DataState
 * @property {number} schemaVersion
 * @property {Bookmark[]} bookmarks
 * @property {BookmarkFolder[]} folders
 * @property {WidgetInstance[]} widgets
 * @property {RecycleBin} recycleBin
 * @property {Array<BookmarkTrashEntry|FolderTrashEntry>} trash
 * @property {Settings} settings
 */

/**
 * @typedef {Object} UIState
 * @property {boolean} isEditing
 * @property {{status: 'idle'|'saving'|'saved'|'error', error: string|null, updatedAt: number|null}} persistence
 * @property {{canUndo: boolean, canRedo: boolean}} history
 */

/**
 * @typedef {Object} AppState
 * @property {DataState} data
 * @property {UIState} ui
 */

/**
 * @typedef {Object<string, string | TranslationTree>} TranslationTree
 */

/**
 * @typedef {Pick<AppState['data'], 'schemaVersion' | 'bookmarks' | 'folders' | 'widgets' | 'recycleBin' | 'trash' | 'settings'>} PersistedData
 */

/**
 * @typedef {Object} SyncCompatibilityBlock
 * @property {'newer-sync-data'} reason
 * @property {number|null} requiredSchemaVersion
 * @property {number} supportedSchemaVersion
 * @property {number|null} requiredSyncFormatVersion
 * @property {number} supportedSyncFormatVersion
 * @property {number} detectedAt
 */
