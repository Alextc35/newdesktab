import '../../types/types.js';
import { DEFAULT_RECYCLE_BIN } from '../../domain/recycle-bin/recycleBinDefaults.js';
import { DEFAULT_SETTINGS } from '../../domain/settings/settingsDefaults.js';
import { normalizeRecycleBinRetentionDays } from '../../domain/settings/recycleBinRetention.js';
import { createDefaultPersistedData } from './persistedDataDefaults.js';
import { DATA_SCHEMA_VERSION } from './schemaVersion.js';
import {
  normalizeBookmark,
  normalizeBookmarkPreset
} from '../../domain/bookmarks/bookmarkModel.js';
import {
  normalizeBookmarkDragMode,
  normalizeBookmarkResizeMode,
  normalizeWindowResizeMode
} from '../../domain/settings/gridInteractionModes.js';
import { normalizeKeyboardShortcuts } from '../../shared/keyboard/keyboardShortcuts.js';
import { normalizeFolderStyle } from '../../domain/folders/folderModel.js';
import { normalizeBackgroundImage } from '../../shared/images/backgroundImage.js';
import { normalizePrimaryVideo, normalizeWallpaperInterval, normalizeWallpaperMedia } from '../../domain/settings/wallpaperMedia.js';
import {
  normalizeInterfaceTheme,
  normalizeLanguagePreference
} from '../../domain/settings/interfacePreferences.js';
import { normalizeRecycleBinStyle } from '../../domain/recycle-bin/recycleBinModel.js';
import {
  normalizeMainWorkspace,
  normalizeWorkspaces,
  resolveWorkspaceId
} from '../../domain/workspaces/workspaceModel.js';
import { normalizeWidgets } from '../../widgets/widgetModel.js';

/**
 * Upgrades and normalizes application data from every supported NewDeskTab
 * version. This is the only entry point for data crossing a persistence or
 * import boundary.
 *
 * @param {Partial<PersistedData>|null|undefined} input
 * @param {Object} [options]
 * @param {boolean} [options.useDefaultsWhenEmpty=true]
 * @returns {PersistedData}
 */
export function migratePersistedData(input, { useDefaultsWhenEmpty = true } = {}) {
  const source = input && typeof input === 'object' ? input : {};
  const sourceVersion = Number.isInteger(source.schemaVersion)
    ? source.schemaVersion
    : 0;

  if (sourceVersion > DATA_SCHEMA_VERSION) {
    const error = new Error('This NewDeskTab data was created by a newer version.');
    error.code = 'UNSUPPORTED_DATA_VERSION';
    error.requiredSchemaVersion = sourceVersion;
    error.supportedSchemaVersion = DATA_SCHEMA_VERSION;
    throw error;
  }

  const rawBookmarks = Array.isArray(source.bookmarks)
    ? source.bookmarks
    : (useDefaultsWhenEmpty ? createDefaultPersistedData().bookmarks : []);
  const rawFolders = Array.isArray(source.folders) ? source.folders : [];
  const rawSettings = source.settings && typeof source.settings === 'object'
    ? source.settings
    : {};
  const now = Date.now();

  const workspaces = normalizeWorkspaces(rawSettings.bookmarkGroups);
  const workspaceIds = new Set(workspaces.map(workspace => workspace.id));
  const activeWorkspaceId = resolveWorkspaceId(
    workspaces,
    rawSettings.activeBookmarkGroupId
  );

  const folders = rawFolders
    .filter(folder => folder && typeof folder === 'object')
    .map((folder, index) => normalizeBookmarkFolder(folder, {
      index,
      now,
      workspaceIds
    }));
  normalizeFolderHierarchy(folders);
  const folderById = new Map(folders.map(folder => [folder.id, folder]));
  const bookmarks = rawBookmarks
    .filter(bookmark => bookmark && typeof bookmark === 'object')
    .map((bookmark, index) => {
      const normalized = normalizeBookmark(bookmark, {
        now,
        touchUpdatedAt: false,
        idFactory: () => `migrated-${now}-${index}`
      });
      normalized.groupId = workspaceIds.has(normalized.groupId)
        ? normalized.groupId
        : null;
      const folder = folderById.get(normalized.folderId);
      normalized.folderId = folder
        && (folder.groupId ?? null) === (normalized.groupId ?? null)
        ? folder.id
        : null;
      return normalized;
    });
  const recycleBin = normalizeRecycleBin(source.recycleBin);
  const widgets = normalizeWidgets(source.widgets, { now, workspaceIds });

  return {
    schemaVersion: DATA_SCHEMA_VERSION,
    bookmarks,
    folders,
    widgets,
    recycleBin,
    trash: normalizeTrashEntries(source.trash, {
      now,
      workspaceIds
    }),
    settings: {
      ...structuredClone(DEFAULT_SETTINGS),
      ...rawSettings,
      language: normalizeLanguagePreference(rawSettings.language),
      interfaceTheme: normalizeInterfaceTheme(rawSettings.interfaceTheme),
      theme: normalizeTheme(rawSettings.theme),
      bookmarkDefault: normalizeBookmarkPreset(rawSettings.bookmarkDefault),
      bookmarkDragMode: normalizeBookmarkDragMode(rawSettings.bookmarkDragMode),
      bookmarkResizeMode: normalizeBookmarkResizeMode(rawSettings.bookmarkResizeMode),
      windowResizeMode: normalizeWindowResizeMode(rawSettings.windowResizeMode),
      keyboardShortcuts: normalizeKeyboardShortcuts(rawSettings.keyboardShortcuts),
      showRecycleBin: rawSettings.showRecycleBin !== false,
      showLauncher: rawSettings.showLauncher !== false
        || !normalizeKeyboardShortcuts(rawSettings.keyboardShortcuts).openSettings,
      showWorkspaceToolbar: rawSettings.showWorkspaceToolbar !== false,
      recycleBinRetentionDays: normalizeRecycleBinRetentionDays(rawSettings.recycleBinRetentionDays),
      bookmarkPresets: normalizeNamedPresets(rawSettings.bookmarkPresets),
      bookmarkGroups: workspaces,
      mainWorkspace: normalizeMainWorkspace(rawSettings.mainWorkspace),
      activeBookmarkGroupId: activeWorkspaceId
    }
  };
}

function normalizeRecycleBin(value) {
  const source = value && typeof value === 'object' ? value : {};
  const w = Math.min(12, normalizeGridSize(source.w ?? DEFAULT_RECYCLE_BIN.w));
  const h = Math.min(6, normalizeGridSize(source.h ?? DEFAULT_RECYCLE_BIN.h));
  return {
    ...structuredClone(DEFAULT_RECYCLE_BIN),
    ...normalizeRecycleBinStyle(source),
    gx: Math.min(12 - w, normalizeGridValue(source.gx ?? DEFAULT_RECYCLE_BIN.gx)),
    gy: Math.min(6 - h, normalizeGridValue(source.gy ?? DEFAULT_RECYCLE_BIN.gy)),
    w,
    h,
    groupId: null,
    updatedAt: normalizeTimestamp(source.updatedAt, 0)
  };
}

function normalizeTrashEntries(value, { now, workspaceIds }) {
  if (!Array.isArray(value)) return [];

  return value.flatMap((entry, entryIndex) => {
    if (!entry || typeof entry !== 'object') return [];
    const deletedAt = normalizeTimestamp(entry.deletedAt, now);
    const id = typeof entry.id === 'string' && entry.id.trim()
      ? entry.id
      : `trash-${now}-${entryIndex}`;

    if (entry.type === 'bookmark' && entry.bookmark && typeof entry.bookmark === 'object') {
      const bookmark = normalizeBookmark(entry.bookmark, {
        now,
        touchUpdatedAt: false,
        idFactory: () => `trashed-bookmark-${now}-${entryIndex}`
      });
      bookmark.groupId = workspaceIds.has(bookmark.groupId) ? bookmark.groupId : null;
      return [{ id, type: 'bookmark', deletedAt, bookmark }];
    }

    if (entry.type === 'folder' && entry.folder && typeof entry.folder === 'object') {
      const folder = normalizeBookmarkFolder(entry.folder, {
        index: entryIndex,
        now,
        workspaceIds
      });
      const nestedFolders = (Array.isArray(entry.folders) ? entry.folders : [])
        .filter(item => item && typeof item === 'object')
        .map((item, index) => normalizeBookmarkFolder({ ...item, groupId: folder.groupId }, {
          index, now, workspaceIds
        }));
      const parentId = folder.parentId;
      folder.parentId = null;
      normalizeFolderHierarchy([folder, ...nestedFolders]);
      folder.parentId = parentId;
      const folderIds = new Set([folder.id, ...nestedFolders.map(item => item.id)]);
      const bookmarks = (Array.isArray(entry.bookmarks) ? entry.bookmarks : [])
        .filter(bookmark => bookmark && typeof bookmark === 'object')
        .map((bookmark, bookmarkIndex) => {
          const normalized = normalizeBookmark(bookmark, {
            now,
            touchUpdatedAt: false,
            idFactory: () => `trashed-folder-bookmark-${now}-${entryIndex}-${bookmarkIndex}`
          });
          normalized.folderId = folderIds.has(normalized.folderId) ? normalized.folderId : folder.id;
          normalized.groupId = folder.groupId;
          return normalized;
        });
      return [{ id, type: 'folder', deletedAt, folder, bookmarks,
        ...(nestedFolders.length ? { folders: nestedFolders } : {}) }];
    }

    return [];
  });
}

function normalizeTheme(value) {
  const source = value && typeof value === 'object' ? value : {};
  const legacyBackgroundColor = typeof source.backgroundColor === 'string'
    ? source.backgroundColor
    : DEFAULT_SETTINGS.theme.backgroundColor;
  const theme = {
    ...structuredClone(DEFAULT_SETTINGS.theme),
    ...source,
    backgroundImageColor: typeof source.backgroundImageColor === 'string'
      ? source.backgroundImageColor
      : legacyBackgroundColor,
    ...normalizeBackgroundImage(source),
    backgroundPrimaryType: source.backgroundPrimaryType === 'video' ? 'video' : 'image',
    backgroundVideo: normalizePrimaryVideo(source.backgroundVideo),
    backgroundMedia: normalizeWallpaperMedia(source.backgroundMedia),
    backgroundRotationSeconds: normalizeWallpaperInterval(source.backgroundRotationSeconds)
  };
  theme.backgroundDefault = theme.backgroundDefault === true;
  theme.backgroundSolid = !theme.backgroundDefault && theme.backgroundSolid === true;
  return theme;
}

function normalizeBookmarkFolder(folder, { index, now, workspaceIds }) {
  const groupId = workspaceIds.has(folder.groupId) ? folder.groupId : null;

  return {
    ...normalizeFolderStyle(folder),
    id: typeof folder.id === 'string' && folder.id.trim()
      ? folder.id
      : `folder-${now}-${index}`,
    name: typeof folder.name === 'string' && folder.name.trim()
      ? folder.name.trim()
      : `Folder ${index + 1}`,
    gx: normalizeGridValue(folder.gx),
    gy: normalizeGridValue(folder.gy),
    w: normalizeGridSize(folder.w),
    h: normalizeGridSize(folder.h),
    groupId,
    parentId: typeof folder.parentId === 'string' && folder.parentId.trim()
      ? folder.parentId : null,
    createdAt: normalizeTimestamp(folder.createdAt, now),
    updatedAt: normalizeTimestamp(folder.updatedAt, now)
  };
}

/** Repairs missing/cross-workspace parents and cycles in legacy/imported data. */
function normalizeFolderHierarchy(folders) {
  const byId = new Map(folders.map(folder => [folder.id, folder]));
  for (const folder of folders) {
    const parent = byId.get(folder.parentId);
    if (!parent || parent.id === folder.id || parent.groupId !== folder.groupId) {
      folder.parentId = null;
    }
  }
  const settled = new Set();
  for (const start of folders) {
    if (settled.has(start.id)) continue;
    const path = [];
    const positions = new Map();
    let folder = start;
    while (folder && !settled.has(folder.id)) {
      if (positions.has(folder.id)) {
        for (const cycleFolder of path.slice(positions.get(folder.id))) cycleFolder.parentId = null;
        break;
      }
      positions.set(folder.id, path.length);
      path.push(folder);
      folder = byId.get(folder.parentId);
    }
    for (const item of path) settled.add(item.id);
  }
}

function normalizeGridValue(value) {
  return Number.isInteger(value) && value >= 0 ? value : 0;
}

function normalizeGridSize(value) {
  return Number.isInteger(value) && value > 0 ? value : 1;
}

function normalizeTimestamp(value, fallback) {
  return Number.isFinite(value) && value >= 0 ? value : fallback;
}

function normalizeNamedPresets(value) {
  if (!Array.isArray(value)) return [];

  return value
    .filter(preset => preset && typeof preset === 'object')
    .map((preset, index) => ({
      id: typeof preset.id === 'string' && preset.id.trim()
        ? preset.id
        : `preset-${index + 1}`,
      name: typeof preset.name === 'string' && preset.name.trim()
        ? preset.name.trim()
        : `Preset ${index + 1}`,
      style: normalizeBookmarkPreset(preset.style ?? preset)
    }));
}

/**
 * Creates the versioned envelope used for complete backups.
 *
 * @param {PersistedData} data
 * @param {{localImages?: Record<string, {dataUrl: string, name?: string}>, localVideos?: Record<string, {dataUrl: string, name?: string}>, devicePreferences?: {dailyTipsEnabled: boolean}}} [options]
 * @returns {{format: string, schemaVersion: number, exportedAt: string, data: PersistedData, localImages: Record<string, {dataUrl: string, name?: string}>, localVideos: Record<string, {dataUrl: string, name?: string}>, devicePreferences?: {dailyTipsEnabled: boolean}}}
 */
export function createBackupEnvelope(data, { localImages = {}, localVideos = {}, devicePreferences } = {}) {
  const envelope = {
    format: 'newdesktab-backup',
    schemaVersion: DATA_SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    data: migratePersistedData(data),
    localImages,
    localVideos
  };
  if (devicePreferences !== undefined) {
    envelope.devicePreferences = parseBackupDevicePreferences({ format: envelope.format, devicePreferences });
  }
  return envelope;
}

/** Read only explicit, validated device preferences from complete backups. */
export function parseBackupDevicePreferences(payload) {
  if (payload?.format !== 'newdesktab-backup' || payload.devicePreferences === undefined) return undefined;
  const preferences = payload.devicePreferences;
  if (!isRecord(preferences) || typeof preferences.dailyTipsEnabled !== 'boolean') throw invalidBackup();
  return { dailyTipsEnabled: preferences.dailyTipsEnabled };
}

/**
 * Creates a portable, versioned bookmarks-only document.
 *
 * @param {Bookmark[]} bookmarks
 * @param {BookmarkFolder[]} [folders=[]]
 * @returns {{format: string, schemaVersion: number, exportedAt: string, bookmarks: Bookmark[], folders: BookmarkFolder[]}}
 */
export function createBookmarksEnvelope(bookmarks, folders = []) {
  const normalized = migratePersistedData({
    bookmarks,
    folders,
    settings: DEFAULT_SETTINGS
  }, { useDefaultsWhenEmpty: false });

  return {
    format: 'newdesktab-bookmarks',
    schemaVersion: DATA_SCHEMA_VERSION,
    exportedAt: new Date().toISOString(),
    bookmarks: normalized.bookmarks,
    folders: normalized.folders
  };
}

/**
 * Accepts current backups and the legacy bookmarks-only array.
 *
 * @param {*} payload
 * @param {PersistedData} [currentData]
 * @returns {PersistedData}
 */
export function parseBackupPayload(payload, currentData = createDefaultPersistedData()) {
  if (Array.isArray(payload)) {
    validateImportedData({ bookmarks: payload });
    return migrateImportedData({
      ...currentData,
      bookmarks: payload,
      folders: []
    });
  }

  if (!isRecord(payload)) throw invalidBackup();
  validateImportedVersion(payload.schemaVersion);
  if (payload.format === 'newdesktab-backup') {
    parseBackupDevicePreferences(payload);
    return migrateImportedData(payload.data);
  }

  if (payload.format === undefined || payload.format === 'newdesktab-bookmarks') {
    return migrateImportedData(payload);
  }

  throw invalidBackup();
}

/**
 * Reads bookmark-only exports, legacy arrays and complete backups while keeping
 * the current settings untouched.
 *
 * @param {*} payload
 * @param {PersistedData} currentData
 * @returns {{bookmarks: Bookmark[], folders: BookmarkFolder[]}}
 */
export function parseBookmarksPayload(payload, currentData = createDefaultPersistedData()) {
  if (payload?.format === 'newdesktab-bookmarks') {
    validateImportedData(payload);
    const migrated = migrateImportedData({
      ...currentData,
      bookmarks: payload.bookmarks,
      folders: payload.folders ?? []
    });
    return { bookmarks: migrated.bookmarks, folders: migrated.folders };
  }

  const restored = parseBackupPayload(payload, currentData);
  const migrated = migrateImportedData({
    ...currentData,
    bookmarks: restored.bookmarks,
    folders: restored.folders
  });
  return { bookmarks: migrated.bookmarks, folders: migrated.folders };
}

/** Validate files before migration can replace malformed collections with defaults. */
function migrateImportedData(value) {
  validateImportedData(value);
  const migrated = migratePersistedData(value, { useDefaultsWhenEmpty: false });
  // Legacy records may receive generated IDs during migration.
  validateImportedData(migrated);
  return migrated;
}

function validateImportedData(value) {
  if (!isRecord(value) || !Array.isArray(value.bookmarks)) throw invalidBackup();
  validateImportedVersion(value.schemaVersion);
  const gridIds = new Set([DEFAULT_RECYCLE_BIN.id]);
  for (const key of ['bookmarks', 'folders', 'widgets']) {
    validateImportedRecords(value[key], gridIds);
  }
  validateImportedRecords(value.trash);
  if (value.recycleBin !== undefined && !isRecord(value.recycleBin)) throw invalidBackup();
  if (value.settings !== undefined) {
    if (!isRecord(value.settings)) throw invalidBackup();
    for (const key of ['theme', 'bookmarkDefault']) {
      if (value.settings[key] !== undefined && !isRecord(value.settings[key])) throw invalidBackup();
    }
    validateImportedRecords(value.settings.bookmarkGroups);
    validateImportedRecords(value.settings.bookmarkPresets);
  }
  for (const entry of value.trash ?? []) {
    if (entry.type === 'bookmark' && isRecord(entry.bookmark)) continue;
    if (entry.type !== 'folder' || !isRecord(entry.folder)) throw invalidBackup();
    const treeIds = new Set();
    validateImportedRecords([entry.folder], treeIds);
    validateImportedRecords(entry.folders, treeIds);
    validateImportedRecords(entry.bookmarks, treeIds);
  }
}

function validateImportedRecords(records, ids = new Set()) {
  if (records === undefined) return;
  if (!Array.isArray(records)) throw invalidBackup();
  for (const record of records) {
    if (!isRecord(record)) throw invalidBackup();
    // Missing IDs in legacy exports are assigned by the normalizer.
    if (record.id === undefined || record.id === null || record.id === '') continue;
    if (typeof record.id !== 'string') throw invalidBackup();
    const id = record.id.trim();
    if (!id) continue;
    if (ids.has(id)) throw invalidBackup('Duplicate imported record ID.');
    ids.add(id);
  }
}

function validateImportedVersion(version) {
  if (version === undefined) return;
  if (!Number.isInteger(version) || version < 0) throw invalidBackup();
  if (version > DATA_SCHEMA_VERSION) {
    const error = new Error('This NewDeskTab data was created by a newer version.');
    error.code = 'UNSUPPORTED_DATA_VERSION';
    error.requiredSchemaVersion = version;
    error.supportedSchemaVersion = DATA_SCHEMA_VERSION;
    throw error;
  }
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function invalidBackup(message = 'Invalid NewDeskTab backup.') {
  const error = new Error(message);
  error.code = 'INVALID_BACKUP';
  return error;
}
